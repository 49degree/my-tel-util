package com.a3650.server.bean.impl;

import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.common.TypeConversion;

public class DownErrorBean extends DownCommandBean{

	/**
	 * 封装数据
	 */
	public byte[] parseBody() {
		return new byte[40];
	}

}
