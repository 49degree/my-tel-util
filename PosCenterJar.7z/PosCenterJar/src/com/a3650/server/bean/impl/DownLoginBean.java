package com.a3650.server.bean.impl;

import com.a3650.server.bean.DownCommandBean;

public class DownLoginBean extends DownCommandBean{
	private String psw; 

	public byte[] parseBody() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getPsw() {
		return psw;
	}

	public void setPsw(String psw) {
		this.psw = psw;
	}
	
	

}
