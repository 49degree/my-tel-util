#include <string.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <gui/Surface.h>
#include <camera/Camera.h>
#include <camera/ICamera.h>
#include <camera/CameraParameters.h>

#include <media/stagefright/CameraSource.h>
#include <media/stagefright/CameraSourceTimeLapse.h>

#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/MetaData.h>
#include <media/stagefright/OMXClient.h>
#include <media/stagefright/OMXCodec.h>

#include <media/IMediaRecorderClient.h>
#include <media/MediaProfiles.h>

#include <android_runtime/AndroidRuntime.h>
#include <android/log.h>

#include <utils/Errors.h>
#include <sys/types.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>

#include <sys/prctl.h>
#include <sys/stat.h>

#include <media/stagefright/foundation/ADebug.h>
#include "ARTPWriter.h"
#include "ARTPWriter1.h"
#include "StagefrightPlayer.h"
#include "VideoPlayer.h"


#define LOGTAG "Test"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOGTAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOGTAG,__VA_ARGS__)


using namespace android;


// ref-counted object for callbacks
class MediaRecorderListener1: public BnMediaRecorderClient
{
public:
	MediaRecorderListener1(){}
    ~MediaRecorderListener1(){}
	void        notify(int msg, int ext1, int ext2){
		LOGE("notify(int msg, int ext1, int ext2) msg=%d",msg);
	}
};






sp<ICamera> mCamera;
sp<ICameraRecordingProxy> mCameraProxy;
sp<Surface> mPreviewSurface;
static bool mIsMetaDataStoredInVideoBuffers;


const static int mFrameRate = 25;
status_t setupCameraSource(sp<CameraSource> *cameraSource) {
	LOGE("118enter setupCameraSource");
	status_t err = OK;
	Size videoSize;
	videoSize.width = 640;
	videoSize.height = 480;


	LOGE("CreateFromCamera CameraSource %d %d mFrameRate %d ",videoSize.width,videoSize.height,mFrameRate);
	*cameraSource  = CameraSource::CreateFromCamera(mCamera, mCameraProxy, 0, String16("com.example.gzdx"), -1, videoSize, mFrameRate, mPreviewSurface->getIGraphicBufferProducer(), true /*storeMetaDataInVideoBuffers*/);
	LOGE("1111CreateFromCamera CameraSource %d %d mFrameRate %d ",videoSize.width,videoSize.height,mFrameRate);
	mCamera.clear();
	mCameraProxy.clear();
	if (*cameraSource == NULL) {
		LOGE("*cameraSource == NULL");
		return UNKNOWN_ERROR;
	}

    mIsMetaDataStoredInVideoBuffers = (*cameraSource)->isMetaDataStoredInVideoBuffers();
	return OK;
}

status_t setupVideoEncoder(sp<MediaSource> cameraSource, int32_t videoBitRate, sp<MediaSource> *source) {
	LOGE("enter setupVideoEncoder");
	source->clear();

	sp < MetaData > enc_meta = new MetaData;
	enc_meta->setInt32(kKeyBitRate, videoBitRate);
	enc_meta->setCString(kKeyMIMEType, MEDIA_MIMETYPE_VIDEO_AVC);
	LOGE("-----------------------------");
	sp < MetaData > meta = cameraSource->getFormat();
	int32_t width, height, stride, sliceHeight, colorFormat,frameRate;
	CHECK(meta->findInt32(kKeyWidth, &width));
	CHECK(meta->findInt32(kKeyHeight, &height));
	CHECK(meta->findInt32(kKeyStride, &stride));
	CHECK(meta->findInt32(kKeySliceHeight, &sliceHeight));
	CHECK(meta->findInt32(kKeyColorFormat, &colorFormat));
	LOGE("colorFormat: %d", colorFormat);
	enc_meta->setInt32(kKeyFrameRate, mFrameRate);
	enc_meta->setInt32(kKeyWidth, width);
	enc_meta->setInt32(kKeyHeight, height);
	enc_meta->setInt32(kKeyIFramesInterval, 1);
	enc_meta->setInt32(kKeyStride, stride);
	enc_meta->setInt32(kKeySliceHeight, sliceHeight);
	enc_meta->setInt32(kKeyColorFormat, colorFormat);

	cameraSource->getFormat()->setInt32(kKeyIFramesInterval, 1);

	//enc_meta->setInt32(kKeySuperFineQuality, 0);



//	if (mVideoTimeScale > 0) {
//		enc_meta->setInt32(kKeyTimeScale, mVideoTimeScale);
//	}
//	LOGE("mVideoEncoderProfile:66" );
//	enc_meta->setInt32(kKeyVideoProfile, 1);
//	LOGE("mVideoEncoderLevel:32");
//	enc_meta->setInt32(kKeyVideoLevel, 32);

	OMXClient client;
	CHECK_EQ(client.connect(), (status_t) OK);

    uint32_t encoder_flags = 0;
    if (mIsMetaDataStoredInVideoBuffers) {
        encoder_flags |= OMXCodec::kStoreMetaDataInVideoBuffers;
    }
    LOGE("encoder_flags ====encoder_flags=%d",encoder_flags);

	enc_meta->dumpToLog();


    sp < MediaSource > encoder = OMXCodec::Create(client.interface(), enc_meta, true /* createEncoder */, cameraSource, NULL, encoder_flags);

	if (encoder == NULL) {
		LOGE("Failed to create the encoder");
		// When the encoder fails to be created, we need
		// release the camera source due to the camera's lock
		// and unlock mechanism.
		cameraSource->stop();
		return UNKNOWN_ERROR;
	}

	*source = encoder;

	return OK;
}


status_t setupVideoDecoder(sp<MediaSource> encoderSource, int32_t videoBitRate, sp<MediaSource> *source) {
	LOGE("enter setupVideoEncoder");
	source->clear();

	const sp < MetaData > enc_meta = new MetaData;
	sp < MetaData > meta = encoderSource->getFormat();

	const char *mimeType;
	CHECK(meta->findCString(kKeyMIMEType, &mimeType));
	enc_meta->setCString(kKeyMIMEType, mimeType);

	int32_t width, height, stride, sliceHeight, colorFormat;
	meta->findInt32(kKeyWidth, &width);
	meta->findInt32(kKeyHeight, &height);
	meta->findInt32(kKeyStride, &stride);
	meta->findInt32(kKeySliceHeight, &sliceHeight);
	meta->findInt32(kKeyColorFormat, &colorFormat);

	LOGE("colorFormat: %d", colorFormat);
	enc_meta->setInt32(kKeyWidth, width);
	enc_meta->setInt32(kKeyHeight, height);
	enc_meta->setInt32(kKeyIFramesInterval, 1);
	enc_meta->setInt32(kKeyStride, stride);
	enc_meta->setInt32(kKeySliceHeight, sliceHeight);
	enc_meta->setInt32(kKeyColorFormat, colorFormat);

	//enc_meta->setInt32(kKeySuperFineQuality, 0);

	OMXClient client;
	CHECK_EQ(client.connect(), (status_t) OK);

    sp < MediaSource > encoder = OMXCodec::Create(client.interface(), enc_meta, false /* createEncoder */, encoderSource, NULL, 0);

	if (encoder == NULL) {
		LOGE("Failed to create the encoder");
		// When the encoder fails to be created, we need
		// release the camera source due to the camera's lock
		// and unlock mechanism.
		encoderSource->stop();
		return UNKNOWN_ERROR;
	}
	*source = encoder;
	return OK;
}

static sp<MediaWriter> mWriter;
static sp<StagefrightPlayer> mStagefrightPlayer;

static sp<VideoPlayer> videoPlayer;
static sp<ALooper> mLooper;

static jint syncSystem(JNIEnv *env, jobject thiz,jobject surfaceHolder)
{
	LOGD( "Execute sync() for file system.");


	//Get Surface object of SurfaceHolder
	jclass clazz = env->GetObjectClass(surfaceHolder);
	jmethodID methodID = env->GetMethodID(clazz, "getSurface", "()Landroid/view/Surface;");
	if (NULL == methodID) {
		LOGE("Fail to call GetMethodID getSurface");
		return 0;
	}

	jobject surfaceObj = env->CallObjectMethod(surfaceHolder, methodID);
	clazz = env->GetObjectClass(surfaceObj);
	if (NULL == clazz) {
		LOGE("Fail to get GetObjectClass of surfaceObj");
		return 0;
	}
	jfieldID fieldID = env->GetFieldID(clazz, "mNativeObject", "I");//mNativeSurface
	if (NULL == fieldID) {
		LOGE("Fail to GetFieldID of mSurface");
		return 0;
	}

	//LOGE("Local surfaceObj=%d,fieldID=%d", surfaceObj, fieldID);

	mPreviewSurface = (Surface*) env->GetIntField(surfaceObj, fieldID);
	//LOGE("mPreviewSurface============ %d",&mPreviewSurface);
	if (mPreviewSurface==0) {
		LOGE("Fail to GetIntField of surface");
		return 0;
	}




	sp <MediaSource> mediaSource;
	sp <CameraSource> cameraSource;
	status_t err = setupCameraSource(&cameraSource);
	LOGE("setupCameraSource end========================");
	mediaSource = cameraSource;
	if (err != OK) {
		return err;
	}


	sp <MediaSource> encodeSource;
	int32_t videoBitRate = 960000;
	LOGE("enter setupVideoEncoder begin");
	err = setupVideoEncoder(mediaSource, videoBitRate, &encodeSource);
	LOGE("enter setupVideoEncoder end");
	if (err != OK) {
		return err;
	}

	/*
	videoPlayer = new VideoPlayer(encodeSource);
	videoPlayer->setSurface(mPreviewSurface);
    mLooper = new ALooper();
    mLooper->setName("ALooper");
	mLooper->registerHandler(videoPlayer);
	mLooper->start();
	videoPlayer->start();



	sp <MediaSource> decodeSource;
	err = setupVideoDecoder(encodeSource, videoBitRate, &decodeSource);
	LOGE("118enter setupVideoDecoder end");
	if (err != OK) {
		return err;
	}
	*/

	int fd = open("/sdcard/myh264.264", O_CREAT | O_LARGEFILE | O_TRUNC | O_RDWR, S_IRUSR | S_IWUSR);

	mWriter = new ARTPWriter();
	mWriter->addSource(encodeSource);
	MediaRecorderListener1 *temp = new MediaRecorderListener1();

    sp<IMediaRecorderClient> listener = interface_cast<IMediaRecorderClient>(temp->asBinder());
	mWriter->setListener(listener);
	LOGE("mWriter->start() begin");
	mWriter->start();
	LOGE("mWriter->start() end111111111 mWriter=%d",(mWriter==NULL));


	/*
	int rfd = open("/sdcard/myh264.264", O_RDONLY, S_IRUSR | S_IWUSR);
	mStagefrightPlayer = new StagefrightPlayer();
	mStagefrightPlayer->setDataSource(rfd,0,0x7ffffffffffffffL);
	mStagefrightPlayer->setVideoSurfaceTexture(mPreviewSurface->getIGraphicBufferProducer());
	mStagefrightPlayer->prepare();
	mStagefrightPlayer->start();
	*/


	return OK;
}

static jint stopSystem(JNIEnv *env, jobject thiz)
{
	LOGE("stopSystem mWriter=%d",(mWriter==NULL));
	if(!(mWriter==NULL)){
		mWriter->stop();
		mWriter=0;
	}
	//delete mHardView;
	return OK;
}
static JNINativeMethod gMethods[] = { 
			{"syncSystem", "(Landroid/view/SurfaceHolder;)I", (void*)syncSystem},
			{"stopSystem", "()I", (void*)stopSystem}
	  };




//=========================================================================
// FunctionName: register_SIPPhone;
// Description : Register SIPPhone native methods to AndroidRuntime;
// Input       : NA;
// Output      : NA;
// ReturnValue : 0: Success; -1: Fail;
// Other       : NA;
//=========================================================================

/*
 * Register native JNI-callable methods.
 * "className" looks like "java/lang/String".
 */
int jniRegisterNativeMethods(JNIEnv* env, const char* className, const JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    LOGE("jniRegisterNativeMethods===================");
    clazz = env->FindClass(className);
    if (clazz == NULL)
        return -1;
    LOGE("%s",className);
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
        return -1;

    return 0;
}

static int register_horitalk(JNIEnv *env) {
	LOGE("register_horitalk===================");
	int ret = AndroidRuntime::registerNativeMethods(env, "com/example/gzdx/Test", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	//int ret = jniRegisterNativeMethods(env, "com/example/gzdx/Test", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	return ret;
}

//=========================================================================
// FunctionName: JNI_OnLoad;
// Description : Init global variables and register native methods;
// Input       : NA;
// Output      : NA;
// ReturnValue : -1: Fail; JNI_VERSION_1_6 Success;
// Other       : NA;
//=========================================================================

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	JNIEnv* env = NULL;
	jint result = -1;
	LOGE("JNI_OnLoad===================");
	if (vm->GetEnv((void**) &env, JNI_VERSION_1_6) != JNI_OK) {
		LOGE("ERROR: GetEnv failed\n");
		return result;
	}

	if (NULL == env) {
		LOGE( "NULL env");
		return result;
	}

	if (0 != register_horitalk(env)) {
		LOGE("Fail to register_horitalk");
		return result;
	}

	//Success Here
	result = JNI_VERSION_1_6;
	return result;
}




/************JNI方法结束**********************/
