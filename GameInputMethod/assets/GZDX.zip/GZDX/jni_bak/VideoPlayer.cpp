#define LOG_NDEBUG 0
#define LOG_TAG "VideoPlayer"
#include <utils/Log.h>
#include "VideoPlayer.h"

#include "SoftwareRenderer.h"
#include <media/stagefright/OMXClient.h>
#include <media/stagefright/OMXCodec.h>
#include <binder/IPCThreadState.h>
//#include <binder/IServiceManager.h>
//#include <media/IMediaPlayerService.h>
#include <media/stagefright/foundation/hexdump.h>
#include <media/stagefright/foundation/ADebug.h>
//#include <media/stagefright/AudioPlayer.h>
//#include <media/stagefright/DataSource.h>
//#include <media/stagefright/FileSource.h>
#include <media/stagefright/MediaBuffer.h>
#include <media/stagefright/MediaDefs.h>
//#include <media/stagefright/MediaExtractor.h>
//#include <media/stagefright/MediaSource.h>
#include <media/stagefright/MetaData.h>
#include <media/stagefright/OMXCodec.h>
#include <gui/Surface.h>
//#include <gui/ISurfaceTexture.h>
//#include <gui/SurfaceTextureClient.h>
#include <gui/ISurfaceComposer.h>

#include <media/stagefright/foundation/ALooper.h>
#include <media/stagefright/foundation/AMessage.h>
#include <cutils/properties.h>
#include <dlfcn.h>
#include <time.h>
#include <ctime>
//#include "../jpeglib/jinterface.h"

#define USE_SURFACE_ALLOC 1
namespace android {

static int64_t getNowUs() {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (int64_t) tv.tv_usec + tv.tv_sec * 1000000ll;
}

//===========================定义渲染器===================================================

struct AwesomeLocalRenderer: public AwesomeRenderer {
//	AwesomeLocalRenderer(const sp<ANativeWindow> &nativeWindow, const sp<MetaData> &meta) :
//		mTarget(new SoftwareRenderer(nativeWindow, meta)) {
//	}

	AwesomeLocalRenderer(const sp<ANativeWindow> &nativeWindow, const sp<MetaData> &meta){
		ALOGE("NEW AwesomeLocalRenderer().//////////");
		meta->dumpToLog();
		mTarget = new SoftwareRenderer(nativeWindow, meta);
	}

	virtual void render(MediaBuffer *buffer) {
		render((const uint8_t *) buffer->data() + buffer->range_offset(), buffer->range_length());
	}

	void render(const void *data, size_t size) {
		mTarget->render(data, size, NULL);
	}

protected:
	virtual ~AwesomeLocalRenderer() {
		delete mTarget;
		mTarget = NULL;
	}

private:
	SoftwareRenderer *mTarget;

	AwesomeLocalRenderer(const AwesomeLocalRenderer &);
	AwesomeLocalRenderer &operator=(const AwesomeLocalRenderer &);
	;
};

struct AwesomeNativeWindowRenderer: public AwesomeRenderer {
	AwesomeNativeWindowRenderer(const sp<ANativeWindow> &nativeWindow, int32_t rotationDegrees) :
		mNativeWindow(nativeWindow) {
		applyRotation(rotationDegrees);
	}

	virtual void render(MediaBuffer *buffer) {
		//ATRACE_CALL();
		int64_t timeUs;
		CHECK(buffer->meta_data()->findInt64(kKeyTime, &timeUs));
		native_window_set_buffers_timestamp(mNativeWindow.get(), timeUs * 1000);
		status_t err = mNativeWindow->queueBuffer_DEPRECATED(mNativeWindow.get(), buffer->graphicBuffer().get());
		if (err != 0) {
			//LOG_E(LOG_TAG,"queueBuffer failed with error %s (%d)", strerror(-err), -err);
			return;
		}

		sp < MetaData > metaData = buffer->meta_data();
		metaData->setInt32(kKeyRendered, 1);
	}

protected:
	virtual ~AwesomeNativeWindowRenderer() {
	}

private:
	sp<ANativeWindow> mNativeWindow;

	void applyRotation(int32_t rotationDegrees) {
		uint32_t transform;
		switch (rotationDegrees) {
		case 0:
			transform = 0;
			break;
		case 90:
			transform = HAL_TRANSFORM_ROT_90;
			break;
		case 180:
			transform = HAL_TRANSFORM_ROT_180;
			break;
		case 270:
			transform = HAL_TRANSFORM_ROT_270;
			break;
		default:
			transform = 0;
			break;
		}

		if (transform) {
			CHECK_EQ(0, native_window_set_buffers_transform(mNativeWindow.get(), transform));
		}
	}

	AwesomeNativeWindowRenderer(const AwesomeNativeWindowRenderer &);
	AwesomeNativeWindowRenderer &operator=(const AwesomeNativeWindowRenderer &);
};

//==============================================================================

status_t VideoPlayer::setSurface(const sp<Surface> &surface) {
	//LOG_V(LOG_TAG,"setPreviewSurface 调用");
	mSurface = surface;
	setNativeWindow_l(surface);
	
	//start();
	return OK;
}
/*
status_t VideoPlayer::setSurfaceTexture(const sp<ISurfaceTexture> &surfaceTexture) {
	//Mutex::Autolock autoLock(mLock);
	mSurface.clear();
	status_t err;
	if (surfaceTexture != NULL) {
		//LOG_V(LOG_TAG,"err = setNativeWindow_l(new SurfaceTextureClient(surfaceTexture));");
		err = setNativeWindow_l(new SurfaceTextureClient(surfaceTexture));
	} else {
		//LOG_V(LOG_TAG,"err = setNativeWindow_l(NULL);");
		err = setNativeWindow_l(NULL);
	}

	return err;
}
*/
status_t VideoPlayer::setNativeWindow_l(const sp<ANativeWindow> &native) {
	mNativeWindow = native;

	return OK;
}

void VideoPlayer::initRenderer_l() {
	//LOG_V(LOG_TAG,"initRenderer_l 被调用");
	/*if (mSurface == NULL) {
	 //LOG_E(LOG_TAG,"mSurface is null!");
	 return;
	 }*/

	if (mNativeWindow == NULL) {
		//LOG_E(LOG_TAG,"mNativeWindow is null!");
		return;
	}

	const sp < MetaData > meta = mDecoder->getFormat();
	meta->setInt32(kKeyColorFormat, OMX_COLOR_FormatYUV420Planar);
	int32_t format;
	const char *component;
	int32_t decodedWidth, decodedHeight;
	CHECK(meta->findInt32(kKeyColorFormat, &format));
	CHECK(meta->findCString(kKeyDecoderComponent, &component));
	CHECK(meta->findInt32(kKeyWidth, &decodedWidth));
	CHECK(meta->findInt32(kKeyHeight, &decodedHeight));

	int32_t rotationDegrees = 0;

	mVideoRenderer.clear();

	//LOG_V(LOG_TAG,"use video component %s", component);
	// previewOnly
	// Must ensure that mVideoRenderer's destructor is actually executed
	// before creating a new one.
	IPCThreadState::self()->flushCommands();

	// Even if set scaling mode fails, we will continue anyway
	//setVideoScalingMode_l( mVideoScalingMode);
	/*if (USE_SURFACE_ALLOC && !strncmp(component, "OMX.", 4) && strncmp(component, "OMX.google.", 11) && strcmp(component, "OMX.Nvidia.mpeg2v.decode")) {
	 // Hardware decoders avoid the CPU color conversion by decoding
	 // directly to ANativeBuffers, so we must use a renderer that
	 // just pushes those buffers to the ANativeWindow.
	 //LOG_V(LOG_TAG,"initRenderer AwesomeNativeWindowRenderer");
	 mVideoRenderer = new AwesomeNativeWindowRenderer(mNativeWindow, rotationDegrees);
	 } else {
	 // Other decoders are instantiated locally and as a consequence
	 // allocate their buffers in local address space.  This renderer
	 // then performs a color conversion and copy to get the data
	 // into the ANativeBuffer.
	 //LOG_V(LOG_TAG,"initRenderer AwesomeLocalRenderer");
	 mVideoRenderer = new AwesomeLocalRenderer(mNativeWindow, meta);
	 }*/

	//LOG_V(LOG_TAG,"initRenderer AwesomeLocalRenderer");
	mVideoRenderer = new AwesomeLocalRenderer(mNativeWindow, meta);
}
//========================================================================

VideoPlayer::VideoPlayer(const sp<MediaSource>& source) :
	mSource(source), mSnapshot(false), mShotBuffer(NULL), mStarted(false) {
	//LOG_V(LOG_TAG,"VideoPlayer object created.");
	mPictures = 0;
	mFps = 0;
	mSkip = 0;
	lasttime = 0;
}

VideoPlayer::~VideoPlayer() {
	//LOG_V(LOG_TAG,"VideoPlayer::~VideoPlayer 析构函数被调用");
	reset();
	mClient.disconnect();

	//LOG_V(LOG_TAG,"VideoPlayer delete finished.");
}

void VideoPlayer::reset() {
	mStarted = false;

	mSource.clear();
	//LOG_V(LOG_TAG,"MediaSource for VideoPlayer clear finished.");
	
	mVideoRenderer.clear();
	//LOG_V(LOG_TAG,"AwesomeRender for videoPlayer clear finished.");

	if (mDecoder != NULL) {
		mDecoder->stop();
		wp < MediaSource > tmp = mDecoder;
		mDecoder.clear();
		while (tmp.promote() != NULL) {
			usleep(1000);
		}
		IPCThreadState::self()->flushCommands();
		//LOG_V(LOG_TAG,"MediaSource of decoder clear finished.");
	}

}

void VideoPlayer::start() {
	if (mSurface == NULL || mStarted) {
		return;
	}
	mStarted = true;
	//LOG_V(LOG_TAG,"start video player.");
	CHECK_EQ(mClient.connect(), (status_t) OK);
	CHECK(mSource->getFormat()->findInt32(kKeyWidth, &mVideoWidth));
	CHECK(mSource->getFormat()->findInt32(kKeyHeight, &mVideoHeight));

	uint32_t flags = 0;
//	flags |= OMXCodec::kEnableGrallocUsageProtected;
//	flags |= OMXCodec::kPreferSoftwareCodecs;
//	flags |= OMXCodec::kClientNeedsFramebuffer;
//	flags |= OMXCodec::kStoreMetaDataInVideoBuffers;
//	flags |= OMXCodec::kUseSecureInputBuffers;

    ALOGE("decoder_flags ====flags=%d",flags);

	mDecoder = OMXCodec::Create(mClient.interface(), mSource->getFormat(), false, mSource, NULL, flags, NULL);



	//mDecoder = new AVCDecoder(mSource);

	////LOG_V(LOG_TAG,"0000000000000000000000");
	CHECK(mDecoder != NULL);
	////LOG_V(LOG_TAG,"11111111111111111111111111111");
	CHECK_EQ(mDecoder->start(), (status_t) OK);
	////LOG_V(LOG_TAG,"222222222222222222222222222222");

	if (mVideoRenderer == NULL) {
		ALOGE("begin initRenderer_l()............");
		sp < MetaData > meta = mDecoder->getFormat();
		meta->dumpToLog();

		initRenderer_l();
	}

	(new AMessage(kWhatPush, id()))->post();

}

bool VideoPlayer::onPush() {
	Mutex::Autolock autoLock(mLock);
	//读取开始
	MediaBuffer *buffer;
	////LOG_V(LOG_TAG,"video read");
	status_t err = mDecoder->read(&buffer);
	////LOG_V(LOG_TAG,"video get");
	if (err != OK) {
		if (err == INFO_FORMAT_CHANGED) {
			int32_t width, height;
			CHECK(mDecoder->getFormat()->findInt32(kKeyWidth, &width));
			CHECK(mDecoder->getFormat()->findInt32(kKeyHeight, &height));
			//LOG_V(LOG_TAG,"INFO_FORMAT_CHANGED %d x %d\n", width, height);
			initRenderer_l(); //add
			(new AMessage(kWhatPush, id()))->post(); //忽略这个问题，后果未知
			return false;
		} else {
			//LOG_E(LOG_TAG,"decoder returned error 0x%08x", err);
			return false;
		}
	}

	if (buffer->range_length() != 0) {
		int64_t deltaTime = 0;
		int64_t timeUs;
		int64_t now = getNowUs();
		CHECK(buffer->meta_data()->findInt64(kKeyTime, &timeUs));

		if (lasttime > 0) {
			deltaTime = timeUs - lasttime - 10000;
			if (deltaTime < 0 || deltaTime > 1000000 || (now - timeUs) > 1000000) {
				deltaTime = 0;
			}
		}
		lasttime = timeUs;
		//LOG_W(LOG_TAG,"deltaTime %lld", deltaTime);
		(new AMessage(kWhatPush, id()))->post(deltaTime);
		mVideoRenderer->render(buffer); //渲染画面，都要渲染，不然bug
	} else {
		(new AMessage(kWhatPush, id()))->post();
	}

	buffer->release();
	buffer = NULL;

	/*////LOG_V(LOG_TAG,"decoder returned frame now %lld ,at time %lld fix %lld \n", now, timeUs, now - timeUs);
	 ////LOG_V(LOG_TAG,"decoder returned frame of size %d at time %.2f secs\n", buffer->range_length(), timeUs / 1E6);
	 //if (mPictures++ % 3 != 0) {
	 if (mSkip > 0) {
	 mSkip--;
	 LOG_W(LOG_TAG,"skipping video frame no delay");

	 } else if (now - timeUs < 1000000) {//只有一秒内解码的才渲染
	 rendered = true;
	 //mVideoRenderer->render(buffer); //渲染画面
	 } else {
	 mSkip = mFps;
	 LOG_W(LOG_TAG,"skipping video frame delay 1 second,mfps = %.2f \n", mFps);
	 }
	 mVideoRenderer->render(buffer); //渲染画面，都要渲染，不然bug

	 //int64_t now = getNowUs();
	 if (mPictures++ == 0) {
	 begintime = now;
	 } else {
	 //mFps = mPictures * 1000000LL / (now - begintime);
	 ////LOG_V(LOG_TAG,"mfps = %.2f \n", mFps);
	 float fps = mPictures * 1000000LL / (now - begintime);
	 if (now - begintime > 10000000LL) {//10秒后
	 if (fps > mFps) {
	 mFps = fps;
	 }
	 } else {
	 mFps = fps;
	 }
	 }
	 if (mFps < 15) {
	 mFps = 15;//写死最低15帧
	 }

	 ////LOG_V(LOG_TAG,"rendered");
	 //}
	 //抓拍数据
	 if (mSnapshot) {
	 mSnapshot = false;
	 time_t timep;
	 struct tm *p;
	 time(&timep);
	 p = localtime(&timep);
	 char filename[100] = { 0 };
	 sprintf(filename, "/mnt/sdcard/hori/img/img_%d_%d_%d_%d_%d_%d.jpeg", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec);
	 jpeg_enc_yuv420((unsigned char*) buffer->data(), mVideoWidth, mVideoHeight, 80, filename);
	 //mShotBuffer = new MediaBuffer(buffer->data(), buffer->size());
	 }
	 }
	 //else{
	 ////LOG_V(LOG_TAG,"decoder returned frame len=%d",buffer->range_length());
	 //}
	 buffer->release();
	 buffer = NULL;

	 if (rendered && mFps > 0) {
	 if (mPictures > 30) {
	 //int delay = 1000000 / mFps - 10000;
	 int delay = (mVideoWidth > 500 ? 800000 : 900000) / mFps;
	 ////LOG_V(LOG_TAG,"delay %d", delay);
	 (new AMessage(kWhatPush, id()))->post(delay);
	 } else {
	 (new AMessage(kWhatPush, id()))->post(20000);
	 }

	 //(new AMessage(kWhatPush, id()))->post(100000);
	 } else {
	 (new AMessage(kWhatPush, id()))->post();
	 }*/

	/*if (rendered) {
	 ////LOG_V(LOG_TAG,"d111111111111");
	 int delay = 0;
	 int64_t now = getNowUs();
	 if (mPictures++ == 0) {
	 ////LOG_V(LOG_TAG,"222222222222222222222");
	 begintime = now;
	 } else {
	 delay = 67000 + lasttime - now;
	 ////LOG_V(LOG_TAG,"delay %d", delay);
	 if (delay < 0) {
	 delay = 0;
	 }
	 }
	 ////LOG_V(LOG_TAG,"delay======== %d", delay);
	 lasttime = now;
	 (new AMessage(kWhatPush, id()))->post(delay);
	 } else {
	 (new AMessage(kWhatPush, id()))->post();
	 }*/

	//(new AMessage(kWhatPush, id()))->post();
	return true;
}

void VideoPlayer::onMessageReceived(const sp<AMessage> &msg) {
	switch (msg->what()) {
	case kWhatPush: {
		onPush();
		break;
	}

	default:
		TRESPASS();
		break;
	}
}

void VideoPlayer::snapshot() {
	//LOG_V(LOG_TAG,"触发抓拍");
	mSnapshot = true;
}

void VideoPlayer::getSnapData(void **data, int *size) {
	//LOG_V(LOG_TAG,"获取抓拍数据");
	if (mShotBuffer != NULL) {
		//LOG_V(LOG_TAG,"获取抓拍数据成功");
		//*data = mShotBuffer->data();
		memcpy(*data, mShotBuffer->data(), mShotBuffer->range_length());
		*size = mShotBuffer->range_length();
	}
	mShotBuffer->release();
	mShotBuffer = NULL;
	// mSnapshot = true;
}

} // namespace android

