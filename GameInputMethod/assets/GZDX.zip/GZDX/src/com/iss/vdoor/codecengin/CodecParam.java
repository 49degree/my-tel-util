package com.iss.vdoor.codecengin;

public class CodecParam {
	
	//视频编码格式
		public static final int PT_H264 = 98;
		//public static final int PT_H263 = 34;
		//public static final int PT_MP4 = 210;
		
		//音频编码格式
		public static final int PT_G711A = 8;
		public static final int PT_G711U = 0;
		public static final int PT_G729  = 18;
		//public static final int PT_G723 = 4;
		//public static final int PT_G729A =         ?;
		//public static final int PT_G729B =         ?;
		//public static final int PT_G729AB =        ?;
		
		//视频分辨率
		public static final int VIDEO_RESL_CIF = 1;
		public static final int VIDEO_RESL_QCIF = 2;
		public static final int VIDEO_RESL_4CIF = 3;
		
		//媒体流传输方向
		public static final int DIRECT_RECVONLY = 0x001;
		public static final int DIRECT_SENDONLY = 0x002;
		public static final int DIRECT_SENDRECV = 0x003;
		public static final int DIRECT_INACTIVE = 0x000;

		
		//公共参数定义
		public int handle = -1; // 媒体管理对象句柄
		public String localIP = ""; // 本地IP
		public String localSessionid = "0"; // 最长20个字符
		public String remoteSessionid = "0"; // 最长20个字符
		
		
		//音频参数定义
		public String remoteAudioIP = ""; // 对端IP
		public int localAudioPort = -1; // 本地音频端口号
		public int remoteAudioPort = -1; // 对端音频端口号
		public String audioPayloadName = "";
		public int audioPayloadID = -1; // 音频payload，支持格式包括        
		public int packettime = 20; // 打包间隔
		public int dtmfBand = 1;   //决定dtmf是inband还是outband
		public int dtmfPayloadID = -1;
		public int audioDirect = DIRECT_INACTIVE; // 音频传输方向 
		
		
		//视频参数定义
		public String remoteVideoIP = ""; // 对端IP
		public int localVideoPort = -1; // 本地视频端口号
		public int remoteVideoPort = -1; // 对端视频端口号
		public String videoPayloadName = "";
		public int videoPayloadID = -1; // 视频payload，支持格式包括
		public int bitRate = -1; // bit rate range: 1-115200
		public int mode = -1;    //-1：普通模式；99：门禁单向视频模式
		public int resolution = -1; // 1 is CIF; 2 is QCIF; 3 is D1, CIF is default.
		public int videoWidth = -1;
		public int videoHeight = -1;
		public int frameRate = -1; // frame rate range:10, 15, 25, 30
		public int H264Level = 0;
		public int videoDirect = DIRECT_INACTIVE; // 视频传输方向
		
	

}
