package com.a3650.server.bean;


/**
 * 上行命令实体类，对应有命令头各个属性和命令体
 */
public abstract class UpCommandBean{
	//命令头信息
	private CommandBean commandBean = null;
	//解析数据失败代码
	private int parseErrorCode = 0;//默认为0=成功，其他失败
	//解析数据失败说明
	private String parseErrorMsg;
	//如果返回的对象parseErrorCode!=0,则解析数据错误，直接返回errorReturnBuffer数据到POS终端
	private byte[] errorReturnBuffer;
	
	public CommandBean getCommandBean() {
		return commandBean;
	}

	public void setCommandBean(CommandBean commandBean) {
		this.commandBean = commandBean;
	}

	public int getParseErrorCode() {
		return parseErrorCode;
	}
	
	public void setParseErrorCode(int parseErrorCode) {
		this.parseErrorCode = parseErrorCode;
	}
	
	public String getParseErrorMsg() {
		return parseErrorMsg;
	}
	
	public void setParseErrorMsg(String parseErrorMsg) {
		this.parseErrorMsg = parseErrorMsg;
	}
	
	public byte[] getErrorReturnBuffer() {
		return errorReturnBuffer;
	}
	
	public void setErrorReturnBuffer(byte[] errorReturnBuffer) {
		this.errorReturnBuffer = errorReturnBuffer;
	}
	
	/**
	 * 解析命令体数据到对象的各个属性中
	 * @param body
	 */
	public abstract void parseBody(byte[] body);
	
}
