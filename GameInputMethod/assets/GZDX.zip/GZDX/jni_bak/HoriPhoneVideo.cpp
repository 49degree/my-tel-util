
#include <media/stagefright/MetaData.h>
#include <media/stagefright/foundation/ADebug.h>
#include <errno.h>
#include "HoriPhoneVideo.h"
#include "log.h"


#define LOG_TAG "HoriPhoneVideo"





namespace android {



HoriPhoneVideo::HoriPhoneVideo():
	mPrepared(false), mVideoSocket(-1)
{
	mPhoneObserver = NULL;
	mInitCheck = 0;
	mVideoPlaying = false;
	mVideoSending = false;
	mInitCheck = 1;
	pRecorder = NULL;

}


int HoriPhoneVideo::SetParameter(void* paraValue)
{
	memcpy(&mParam, paraValue, sizeof(mParam));
	return 1;
}

int HoriPhoneVideo::Prepare()
{
	Mutex::Autolock autoLock(mLock);
	mPrepared = true;


	//�ڴ�������ƵRTP�˿�
	if (mParam.localVideoPort > 0) {
		if (mVideoSocket <= 0) {//��ʼ����Ƶ�˿�
			LOG_D(LOG_TAG,"init video socket");
			unsigned videoPort = mParam.localVideoPort;
			mVideoSocket = MakeUDPSocket(videoPort);
			LOG_D(LOG_TAG,"mVideoSocket=%d", mVideoSocket);
			if(mVideoSocket < 0)
			{
				LOG_E(LOG_TAG,"Create socket for video fail, end prepare for video.");
				return -1;
			}
		}

		//if (mPhoneParam.videoDirect == 3 || mPhoneParam.videoDirect == 2) {
		if (mParam.videoDirect == MEDIA_DIRECT_SENDRECV) {
			if (mVideoRecorder == NULL) {
				LOG_V(LOG_TAG,"init VideoRecorder");
				mVideoRecorder = new VideoRecorder();
				//mVideoRecorder->setCamera(mCamera);
				//mVideoRecorder->setPreviewSurface(Test::getISurface(localSurface)); //->getISurface()
				mVideoRecorder->setParamVideoEncodingBitRate(mParam.bitRate);
				mVideoRecorder->setParamVideoIFramesInterval(1);
				mVideoRecorder->setVideoFrameRate(mParam.frameRate);

				//Ŀǰ���ֻ֧�ְ�VGA�ֱ��ʽ��б���
				if(mParam.resolution == VIDEO_RESOLITION_4CIF)
				{
					mVideoRecorder->setVideoSize(640, 480);
				}
				else
				{
					mVideoRecorder->setVideoSize(mParam.videoWidth, mParam.videoHeight);
				}
				
			}

		}
	}


	//RTP���ݵײ㴦����ʼ
	if (mRTPSession == NULL) {
		LOG_D(LOG_TAG,"init rtp connection for video session.");
		rtpLooper = new ALooper;
		rtpLooper->start();

		mRTPSession = new AVideoRTPSession();
		if (mParam.mode == 99) {//�ſڻ�ģʽ
			mRTPSession->setNat();
		}

		mRTPSession->addListener(this);
		mRTPSession->setupConn(mVideoSocket,mParam.videoPayloadID,mParam.handle, mParam.remoteIP, mParam.remoteVideoPort, mParam.localSessionid, mParam.remoteSessionid);
		rtpLooper->registerHandler(mRTPSession);

		buildSDP();

		sp < ASessionDescription > desc = new ASessionDescription;
		CHECK(desc->setTo(mParam.spec, strlen(mParam.spec)));
		CHECK_EQ(mRTPSession->setup(desc), (status_t) OK);
		//CHECK_EQ(mRTPSession->countTracks(), 1u);
		CHECK_GE(mRTPSession->countTracks(), 1u);
		//sp < MediaSource > source = mRTPSession->trackAt(0);
	} else {//����sdp
		LOG_V(LOG_TAG,"update rtp connection for video session");
		mRTPSession->setupConn(mVideoSocket,mParam.videoPayloadID,mParam.handle, mParam.remoteIP, mParam.remoteVideoPort, mParam.localSessionid, mParam.remoteSessionid);
		sp < ASessionDescription > desc = new ASessionDescription;
		CHECK(desc->setTo(mParam.spec, strlen(mParam.spec)));
		CHECK_EQ(mRTPSession->update(desc), (status_t) OK);
		CHECK_GE(mRTPSession->countTracks(), 1u);

	}

	if (mVideoSocket > 0) {
		//if (mPhoneParam.videoDirect == 3 || mPhoneParam.videoDirect == 1) {//sendrecv or recvonly
		if (mParam.videoDirect == MEDIA_DIRECT_SENDRECV || mParam.mode == 99) {//sendrecv or recvonly
			if (mVideoPlayer == NULL) {
				LOG_D(LOG_TAG,"init VideoPlayer");
				sp < MediaSource > videoSource = mRTPSession->getTrack();
				vpLooper = new ALooper;
				vpLooper->start();

				mVideoPlayer = new VideoPlayer(videoSource);
				vpLooper->registerHandler(mVideoPlayer); //ע�ᵽrtpLooper������⣬��֪��Ϊʲô...
				//mVideoPlayer->setSurface(mPreviewSurface); //2.3
				//mVideoPlayer->start();
				LOG_D(LOG_TAG,"init VideoPlayer end");
			}
		}
	}	

	
	return 1;

}


int HoriPhoneVideo::Start()
{
	Mutex::Autolock autoLock(mLock);

	//if (mVideoRecorder != NULL && !mVideoSending && mCamera != 0) {
	if (mVideoRecorder != NULL && !mVideoSending) {
		//LOG_V(LOG_TAG,"ccccccccccccccccccc");
		//mVideoRecorder->setCamera(mCamera);
		//mVideoRecorder->setPreviewSurface(localSurface); //->getISurface()
		mVideoRecorder->setupConn(mVideoSocket, mParam.remoteIP, mParam.remoteVideoPort, mParam.videoPayloadID); //�Ǵ�͸ģʽ
		mVideoRecorder->start();
		mVideoSending = true;

	}

	/*if (mVideoPlayer != NULL) {
	 mVideoPlayer->setSurface(Test::getISurface(remoteSurface)); //2.3
	 }*/

	playVideo();

	/*if (mPlayer != NULL) {
	 //mPlayer->start(); //���жϣ������ظ�����
	 if (remoteSurface != NULL) {
	 sp < ISurface > isurface = Test::getISurface(remoteSurface);
	 mPlayer->setPreviewSurface(isurface);
	 } else {
	 LOG_E(LOG_TAG,"remoteSurface is not set yet!");
	 }

	 mPlayer->playAudio();
	 mPlayer->playVideo();
	 }*/

	//mRecoder->start();

	return 1;



}


void HoriPhoneVideo::playVideo()
{
	if (mVideoPlayer != NULL && !mVideoPlaying) {
		//LOG_V(LOG_TAG,"bbbbbbbbbbbbbbbb");
		mVideoPlaying = true;
		if (remoteSurface != NULL) {
			mVideoPlayer->setSurface(remoteSurface); //2.3
			//mVideoPlayer->setSurfaceTexture(remoteSurface->getSurfaceTexture());
		}
		/*else {
			LOG_E(LOG_TAG,"remoteSurface is not set yet!");
			return;
		}*/
		//mVideoPlayer->start();
		//2014.07.14 �ĳ� ����surface֮��������
		//mRTPSession->receivingPackage(); �
	}

}

int HoriPhoneVideo::Stop(void) {
	Mutex::Autolock autoLock(mLock);
	LOG_D(LOG_TAG,"Now stop video session.");


	//֪ͨ¼����ֹͣ¼��
	if(pRecorder != NULL)
	{
		pRecorder->onVideoStop();
		LOG_D(LOG_TAG,"HoriPhone::pRecorder->onVideoStop");
	}

	mRTPSession.clear();
	if (rtpLooper != NULL) {
		rtpLooper->stop();
		LOG_V(LOG_TAG,"�ر�rtp�ɹ�");
	}

	
	mVideoPlayer.clear();
	if (vpLooper != NULL) {
		vpLooper->stop();
		LOG_V(LOG_TAG,"�ر���Ƶ���ųɹ�");
	}

	
	close( mVideoSocket); //�ڴ�ͳһ�ر�rtp��Ƶ�˿�
	mVideoSocket = -1;
	LOG_V(LOG_TAG,"�ر���Ƶrtp�����˿ڳɹ�");


	if (mVideoRecorder != NULL)
	{
		mVideoRecorder->stop();
		mVideoRecorder.clear();
		LOG_V(LOG_TAG,"�ر���Ƶ��¼����ɹ�");
	}

	
	mVideoPlaying = false;
	mVideoSending = false;

	LOG_D(LOG_TAG,"HoriPhoneVideo::Stop �������");
	return 1;
}


int HoriPhoneVideo::SwitchVideoOnOff(int oprID) {
	//return mPVPhone->SwitchVideoOnOff(channelID);

	switch(oprID)
	{
	case SIP2WAY_CHID_AUDIO_SINK:    //����������
	break;
	case SIP2WAY_CHID_AUDIO_SOURCE:    //MIC����
	break;
	case SIP2WAY_CHID_VIDEO_SOURCE:    //�ر�����ͷ
		mVideoSending = false;
		if (mVideoRecorder != NULL) {
			LOG_V(LOG_TAG,"-----�ر�����ͷ------");
			mVideoRecorder->stop();
			mVideoRecorder.clear();
			LOG_V(LOG_TAG,"---�ر�����ͷ�ɹ�----");
		}
	break;
	case SIP2WAY_CHID_VIDEO_SINK:   //�ر���Ƶ������
		LOG_V(LOG_TAG,"-----�ر���Ƶ����------");
		mVideoPlaying = false;
		mRTPSession->getTrack()->stop();
		if (mVideoPlayer != NULL) {
			mVideoPlayer.clear();
			if (vpLooper != NULL) {
				vpLooper->stop();
			}
		}
		if (mVideoPlayer == NULL) {
			LOG_V(LOG_TAG,"mVideoPlayer is NULL now");
		}
		mRTPSession->removeVideoTrack();
		LOG_V(LOG_TAG,"---�ر���Ƶ���ųɹ�----");
	break;
	}

	return 1;

}



void HoriPhoneVideo::setCamera(int camera) {

	LOG_V(LOG_TAG,"setCamera for video session");
	if (mVideoRecorder != NULL) {
		mVideoRecorder->setParamVideoCameraId(0);//camera
	}
	return;
}


int HoriPhoneVideo::setLocalSurface(const sp<Surface>& surface) {

	LOG_V(LOG_TAG,"setLocalSurface for video session");
	if (surface == 0) {
		LOG_E(LOG_TAG,"surface is NULL");
		return 0;
	}

	localSurface = surface;
	
	if (mVideoRecorder != NULL ) {
		mVideoRecorder->setPreviewSurface(localSurface); //->getISurface()
	}
	return 1;
}

//void HoriPhone::setCameraSource(const sp<MediaSource>& source) {
//    mCameraSource = source;
//}

int HoriPhoneVideo::setRemoteSurface(const sp<Surface>& surface) {
	LOG_V(LOG_TAG,"111188888setRemoteSurface for video sesion");
	if (surface == 0) {
		LOG_E(LOG_TAG,"surface is NULL");
		return 0;
	}
	LOG_V(LOG_TAG,"setRemoteSurface done!");
	remoteSurface = surface;
	
	if (mVideoPlayer != NULL) {
		mVideoPlayer->setSurface(remoteSurface); //2.3
		//2014.07.14 �ĳ�����surface֮������
		mRTPSession->receivingPackage();
	}

	return 1;
}


bool HoriPhoneVideo::CompareParam(VideoParam* pParam)
{
	if(pParam == NULL)
		return false;

	if(0 != strcmp(mParam.remoteIP, pParam->remoteIP))
		return false;

	if(0 != strcmp(mParam.localIP, pParam->localIP))
		return false;

	if(mParam.localVideoPort != pParam->localVideoPort)
		return false;

	if(mParam.remoteVideoPort != pParam->remoteVideoPort)
		return false;

	if(0 != strcmp(mParam.videoPayloadName, pParam->videoPayloadName))
		return false;

	if(mParam.videoPayloadID != pParam->videoPayloadID)
		return false;

	if(mParam.resolution != pParam->resolution)
		return false;

	if(mParam.videoWidth != pParam->videoWidth)
		return false;

	if(mParam.videoHeight != pParam->videoHeight)
		return false;

	if(mParam.bitRate != pParam->bitRate)
		return false;

	if(mParam.frameRate != pParam->frameRate)
		return false;

	if(mParam.mode != pParam->mode)
		return false;
	
	if(mParam.videoDirect != pParam->videoDirect)
		return false;


	return true;


}




void HoriPhoneVideo::onRemoteVideoRtpBind(int rtpPort) {
	LOG_D(LOG_TAG,"�������Զ���ƵRTP�˿ڰ󶨳ɹ�,�˿ں�=%d", rtpPort);
	if (mVideoRecorder != NULL) {
		mVideoRecorder->setupConn(mVideoSocket, mParam.remoteIP, rtpPort, mParam.videoPayloadID);
	}
}


void HoriPhoneVideo::onGetFirstIframe() {
	LOG_D(LOG_TAG,"��������һ����ƵI֡");

	if (mVideoPlaying && mVideoPlayer != NULL) {
		mVideoPlayer->start();
	}

}



int HoriPhoneVideo::MakeUDPSocket(unsigned port) {
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	CHECK_GE(s, 0);

	struct sockaddr_in addr;
	memset(addr.sin_zero, 0, sizeof(addr.sin_zero));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(port);

	if(0 > bind(s, (const struct sockaddr *) &addr, sizeof(addr)))
	{
		LOG_E(LOG_TAG,"Bind socket to port %d for video fail, err=%d.", port, errno);
		return -1;
	}
	return s;
}


void HoriPhoneVideo::buildSDP()
{
	sprintf(mParam.spec, "v=0\r\n");
	sprintf(mParam.spec, "%so=- %d %d IN IP4 %s\r\n", mParam.spec, mParam.localSessionid, mParam.remoteSessionid, mParam.remoteIP);
	sprintf(mParam.spec, "%ss=SBC call\r\n", mParam.spec);
	sprintf(mParam.spec, "%sc=IN %s\r\n", mParam.spec, mParam.remoteIP);
	sprintf(mParam.spec, "%st=0 0\r\n", mParam.spec);

	sprintf(mParam.spec, "%sm=video %d RTP/AVP %d\r\n", mParam.spec, mParam.remoteVideoPort,  mParam.videoPayloadID);
	if(0 == strcmp(mParam.videoPayloadName,"H.264"))
	{
		sprintf(mParam.spec, "%sa=rtpmap:%d H264/90000\r\n", mParam.spec, mParam.videoPayloadID);
		sprintf(mParam.spec, "%sa=fmtp:%d profile-level-id=42e014;sprop-parameter-sets=Z0LgHtsCwEkQ,aM4wpIA=;packetization-mode=1;max-br=%d\r\n", 
								mParam.spec, mParam.videoPayloadID, mParam.bitRate);
	
	}
	switch(mParam.videoDirect)
	{
	case MEDIA_DIRECT_SENDRECV:
		sprintf(mParam.spec, "%sa=sendrecv\r\n", mParam.spec);
	break;
	case MEDIA_DIRECT_INACTIVE:
		sprintf(mParam.spec, "%sa=inactive\r\n", mParam.spec);
	break;
	case MEDIA_DIRECT_RECVONLY:
		sprintf(mParam.spec, "%sa=recvonly\r\n", mParam.spec);
	break;
	case MEDIA_DIRECT_SENDONLY:
		sprintf(mParam.spec, "%sa=sendonly\r\n", mParam.spec);
	break;
	}

	LOG_D(LOG_TAG,"SDP for video is constructed: \r\n%s", mParam.spec);


}



}






