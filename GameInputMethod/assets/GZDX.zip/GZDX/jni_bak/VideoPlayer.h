#ifndef VIDEO_PLAYER_H_

#define VIDEO_PLAYER_H_

#include <media/stagefright/foundation/AHandler.h>
#include <media/stagefright/MediaSource.h>

#include <media/MediaPlayerInterface.h>
//#include <media/stagefright/DataSource.h>
#include <media/stagefright/OMXClient.h>
//#include <media/stagefright/TimeSource.h>
#include <utils/threads.h>
#include <utils/List.h>
namespace android {

struct AwesomeRenderer: public RefBase {

	AwesomeRenderer() {
	}

	virtual void render(MediaBuffer * buffer) = 0;

private:
	AwesomeRenderer(const AwesomeRenderer &);
	AwesomeRenderer &operator=(const AwesomeRenderer &);
};

struct VideoPlayer: public AHandler {
	VideoPlayer(const sp<MediaSource>& source);
	void start();
	void reset();
	status_t setSurface(const sp<Surface> &surface);
	//status_t setSurfaceTexture(const sp<ISurfaceTexture> &surfaceTexture);

	void snapshot();
	void getSnapData(void **data, int *size);

protected:
	virtual ~VideoPlayer();
	virtual void onMessageReceived(const sp<AMessage> &msg);

private:

	enum {
		kWhatPush = 'push', kWhatRender = 'render'
	};

	bool mStarted;
	Mutex mLock;
	int mSkip;
	int64_t mPictures;//跳帧计数器
	int64_t begintime;
	int64_t lasttime;
	float mFps;
	bool mSnapshot; //抓拍标志
	MediaBuffer *mShotBuffer; //抓拍数据
	//List<MediaBuffer *> mBuffers;

	sp<MediaSource> mSource;
	sp<MediaSource> mDecoder;

	OMXClient mClient;

	sp<Surface> mSurface;
	sp<ANativeWindow> mNativeWindow;
	sp<AwesomeRenderer> mVideoRenderer;

	int32_t mVideoWidth, mVideoHeight;

	bool onPush();
	//bool onRender();

	//int mPictures;
	status_t setNativeWindow_l(const sp<ANativeWindow> &native);
	void initRenderer_l();

	DISALLOW_EVIL_CONSTRUCTORS( VideoPlayer);
};

} // namespace android

#endif  // VIDEO_PLAY_H_
