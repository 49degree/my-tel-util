package com.a3650.server.bean.impl;

import com.a3650.server.bean.DownCommandBean;

public class DownSaleBillBean extends DownCommandBean{


	public byte[] parseBody() {
		// TODO Auto-generated method stub
		return null;
	}
}
