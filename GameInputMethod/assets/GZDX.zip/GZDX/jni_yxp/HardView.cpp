#define LOG_TAG "HardView"

#include <utils/Log.h>
#include <cutils/properties.h>

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES/gl.h>
#include <GLES/glext.h>

#include <androidfw/AssetManager.h>

#include <ui/PixelFormat.h>
#include <ui/Rect.h>
#include <ui/Region.h>
#include <ui/DisplayInfo.h>
#include <ui/FramebufferNativeWindow.h>

#include <core/SkBitmap.h>
#include <core/SkStream.h>
#include <core/SkImageDecoder.h>

#include <gui/ISurfaceComposer.h>
#include <gui/Surface.h>
#include <gui/SurfaceComposerClient.h>
#include <private/gui/LayerState.h>





#include "HardView.h"

namespace android {

HardView::HardView(int w,int h,sp<MetaData> meta):
	videoW(w),videoH(h),mMeta(meta){
	mMeta->dumpToLog();
	ALOGE("HardView()===============mTarget=%d",mTarget);
	mSession = new SurfaceComposerClient();
	startTime = 0;
}

void HardView::onFirstRef() {
	ALOGD("onFirstRef-----------");
	status_t err = mSession->linkToComposerDeath(this);
	if (err == NO_ERROR) {
		ALOGE("linkToComposerDeath failed (%s) ", strerror(-err));
	}
}

void HardView::binderDied(const wp<IBinder>& who)
{
    // woah, surfaceflinger died!
    ALOGD("SurfaceFlinger died, exiting...");
    // calling requestExit() is not enough here because the Surface code
    // might be blocked on a condition variable that will never be updated.
    kill( getpid(), SIGKILL );
}

HardView::~HardView(){
	ALOGE("~HardView()===============");
	stop = true;
	checkExit();
	if(mDisplay){
		ALOGE("release ===============");
	    eglMakeCurrent(mDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	    eglDestroyContext(mDisplay, mContext);
	    eglDestroySurface(mDisplay, mSurface);
	    mFlingerSurface.clear();
	    mFlingerSurfaceControl.clear();
	    eglTerminate(mDisplay);
	}
	delete mTarget;
    mTarget = NULL;
}

sp<SurfaceComposerClient> HardView::session() const {
    return mSession;
}

status_t HardView::setImage(MediaBuffer* mediaBuffer){
  ALOGE("setImage()===============");
//
//	ALOGE("mediaBuf length=%d", mediaBuffer->range_length());
//	sp<MetaData> meta = mediaBuffer->meta_data();
//	meta->dumpToLog();
//	initTexture(mediaBuffer->data(),mediaBuffer->range_length(),videoW,videoH);

	 mTarget->render((const uint8_t *)mediaBuffer->data() + mediaBuffer->range_offset(), mediaBuffer->range_length(), NULL);
//
//
	return OK;
}
status_t HardView::initWindow(){
	ALOGE("initWindow()===============");
	mAssets.addDefaultAssets();
    sp<IBinder> dtoken(SurfaceComposerClient::getBuiltInDisplay(
            ISurfaceComposer::eDisplayIdMain));
    DisplayInfo dinfo;
    status_t status = SurfaceComposerClient::getDisplayInfo(dtoken, &dinfo);
    if (status)
        return -1;
    SurfaceComposerClient::setDisplayProjection(dtoken, DisplayState::eOrientationDefault | DisplayState::eOrientationLock, Rect(dinfo.w, dinfo.h), Rect(dinfo.w, dinfo.h));

    // create the native surface
    sp<SurfaceControl> control = session()->createSurface(String8("HardView"),
            videoW, videoH, PIXEL_FORMAT_RGB_565);


    control->setPosition(700, 200);


    SurfaceComposerClient::openGlobalTransaction();
    control->setLayer(0x40000000);
    SurfaceComposerClient::closeGlobalTransaction();
    sp<Surface> s = control->getSurface();
    // initialize opengl and egl
      const EGLint attribs[] = {
              EGL_RED_SIZE,   8,
              EGL_GREEN_SIZE, 8,
              EGL_BLUE_SIZE,  8,
              EGL_DEPTH_SIZE, 0,
              EGL_NONE
      };

      EGLint w, h, dummy;
      EGLint numConfigs;
      EGLConfig config;
      EGLSurface surface;
      EGLContext context;

      EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
      eglInitialize(display, 0, 0);
		eglChooseConfig(display, attribs, &config, 1, &numConfigs);
		surface = eglCreateWindowSurface(display, config, s.get(), NULL);
		context = eglCreateContext(display, config, NULL, NULL);
		eglQuerySurface(display, surface, EGL_WIDTH, &w);
		eglQuerySurface(display, surface, EGL_HEIGHT, &h);
		if (eglMakeCurrent(display, surface, surface, context) == EGL_FALSE)
			return NO_INIT;
		mDisplay = display;
		mContext = context;
		mSurface = surface;
		mWidth = w;
		mHeight = h;
		ALOGE("initWindow()7===============mWidth=%d;mHeight=%d",mWidth,mHeight);
		mFlingerSurfaceControl = control;
		mFlingerSurface = s;

		mMeta->dumpToLog();
		ALOGE("init SoftwareRenderer===============mFlingerSurface=%d",mFlingerSurface.get());
		mTarget = new SoftwareRenderer(mFlingerSurface,mMeta);

		android();
		 /**/
      return OK;
}

static GLint xc,yc;
static nsecs_t lastTime;
bool HardView::android()
{
	ALOGE("android first==============startTime=%d",startTime);
	if(startTime==0){
		ALOGE("android first==============111");
//	    initTexture(&mAndroid[0], mAssets, "images/android-logo-mask.png");
//	    initTexture(&mAndroid[1], mAssets, "images/android-logo-shine.png");

	    // clear screen
	    glShadeModel(GL_FLAT);
	    glDisable(GL_DITHER);
	    glDisable(GL_SCISSOR_TEST);
	    glClearColor(0,0,0,1);
	    glClear(GL_COLOR_BUFFER_BIT);
	    eglSwapBuffers(mDisplay, mSurface);

//	    glEnable(GL_TEXTURE_2D);
//	    glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
//
//	    xc = (mWidth  - mAndroid[0].w) / 2;
//	    yc = (mHeight - mAndroid[0].h) / 2;
//	    const Rect updateRect(xc, yc, xc + mAndroid[0].w, yc + mAndroid[0].h);
//
//	    glScissor(updateRect.left, mHeight - updateRect.bottom, updateRect.width(),
//	            updateRect.height());

	    // Blend state
//	    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
//	    glTexEnvx(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	    startTime = systemTime();
	}

	/*
	nsecs_t now = systemTime();
	ALOGE("android ==============");
    // 12fps: don't animate too fast to preserve CPU
    const nsecs_t sleepTime = 83333 - ns2us(now - lastTime);
    if (sleepTime > 0)
    	return true;
    ALOGE("android view==============");
	double time = now - startTime;
    float t = 4.0f * float(time / us2ns(16667)) / mAndroid[1].w;
    GLint offset = (1 - (t - floorf(t))) * mAndroid[1].w;
    GLint x = xc - offset;

    glDisable(GL_SCISSOR_TEST);
    glClear(GL_COLOR_BUFFER_BIT);

    glEnable(GL_SCISSOR_TEST);
    glDisable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, mAndroid[1].name);
    glDrawTexiOES(x,                 yc, 0, mAndroid[1].w, mAndroid[1].h);
    glDrawTexiOES(x + mAndroid[1].w, yc, 0, mAndroid[1].w, mAndroid[1].h);

    glEnable(GL_BLEND);
    glBindTexture(GL_TEXTURE_2D, mAndroid[0].name);
    glDrawTexiOES(xc, yc, 0, mAndroid[0].w, mAndroid[0].h);

    EGLBoolean res = eglSwapBuffers(mDisplay, mSurface);
    if (res == EGL_FALSE)
        return false;
    lastTime = systemTime();
    */
    return true;
}

status_t HardView::initTexture(void* buffer, size_t len,int width,int height)
{

	ALOGD("initTexture2----------------...");
    SkBitmap bitmap;
    bitmap.setConfig(SkBitmap::kRGB_565_Config, width, height);
    new SkBitmap(bitmap);

    //SkAutoLockPixels alp(*bitmap);
    void* dst = bitmap.getPixels();

    if (NULL != dst) {
        //android::AutoBufferPointer abp(env, jbuffer, JNI_FALSE);
        // the java side has already checked that buffer is large enough
        memcpy(dst, buffer, len);
        (&bitmap)->notifyPixelsChanged();
    }



//    SkMemoryStream  stream(buffer, len);
//    SkImageDecoder* codec = SkImageDecoder::Factory(&stream);
//    codec->setDitherImage(false);
//    if (codec) {
//        codec->decode(&stream, &bitmap,
//                SkBitmap::kARGB_8888_Config,
//                SkImageDecoder::kDecodePixels_Mode);
//        delete codec;
//    }

    // ensure we can call getPixels(). No need to call unlock, since the
    // bitmap will go out of scope when we return from this method.
    bitmap.lockPixels();

    const int w = bitmap.width();
    const int h = bitmap.height();
    const void* p = bitmap.getPixels();

    ALOGI("initTexture2----------------w=%d;h=%d;type=%d",w,h,bitmap.getConfig());

    GLint crop[4] = { 0, h, w, -h };
    int tw = 1 << (31 - __builtin_clz(w));
    int th = 1 << (31 - __builtin_clz(h));
    if (tw < w) tw <<= 1;
    if (th < h) th <<= 1;

    switch (bitmap.getConfig()) {
        case SkBitmap::kARGB_8888_Config:
            if (tw != w || th != h) {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA,
                        GL_UNSIGNED_BYTE, 0);
                glTexSubImage2D(GL_TEXTURE_2D, 0,
                        0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, p);
            } else {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA,
                        GL_UNSIGNED_BYTE, p);
            }
            break;

        case SkBitmap::kRGB_565_Config:
            if (tw != w || th != h) {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tw, th, 0, GL_RGB,
                        GL_UNSIGNED_SHORT_5_6_5, 0);
                glTexSubImage2D(GL_TEXTURE_2D, 0,
                        0, 0, w, h, GL_RGB, GL_UNSIGNED_SHORT_5_6_5, p);
            } else {
                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, tw, th, 0, GL_RGB,
                        GL_UNSIGNED_SHORT_5_6_5, p);
            }
            break;
        default:
            break;
    }

    glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    /**/
    return NO_ERROR;
}

status_t HardView::initTexture(Texture* texture, AssetManager& assets,const char* name) {

    Asset* asset = assets.open(name, Asset::ACCESS_BUFFER);

    if (!asset)
        return NO_INIT;
    SkBitmap bitmap;
    SkImageDecoder::DecodeMemory(asset->getBuffer(false), asset->getLength(),
            &bitmap, SkBitmap::kNo_Config, SkImageDecoder::kDecodePixels_Mode);
    asset->close();
    delete asset;

    // ensure we can call getPixels(). No need to call unlock, since the
    // bitmap will go out of scope when we return from this method.
    bitmap.lockPixels();

    const int w = bitmap.width();
    const int h = bitmap.height();
    const void* p = bitmap.getPixels();

    GLint crop[4] = { 0, h, w, -h };
    texture->w = w;
    texture->h = h;

    glGenTextures(1, &texture->name);
    glBindTexture(GL_TEXTURE_2D, texture->name);
    ALOGE("bitmap.getConfig(==============%d",bitmap.getConfig());
    switch (bitmap.getConfig()) {
        case SkBitmap::kA8_Config:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_ALPHA, w, h, 0, GL_ALPHA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case SkBitmap::kARGB_4444_Config:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_SHORT_4_4_4_4, p);
            break;
        case SkBitmap::kARGB_8888_Config:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA,
                    GL_UNSIGNED_BYTE, p);
            break;
        case SkBitmap::kRGB_565_Config:
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB,
                    GL_UNSIGNED_SHORT_5_6_5, p);
            break;
        default:
            break;
    }

    glTexParameteriv(GL_TEXTURE_2D, GL_TEXTURE_CROP_RECT_OES, crop);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterx(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    ALOGE("initTexture==============");
    /**/
    return NO_ERROR;
}


void HardView::checkExit() {
	ALOGE("checkExit ===============");
	if(exitFlag)
		return ;
	exitFlag = true;
	ALOGE("checkExit 11111===============");

    glDeleteTextures(1, &mAndroid[0].name);
    glDeleteTextures(1, &mAndroid[1].name);

    sp<IBinder> dtoken(SurfaceComposerClient::getBuiltInDisplay(
             ISurfaceComposer::eDisplayIdMain));
     DisplayInfo dinfo;
     status_t status = SurfaceComposerClient::getDisplayInfo(dtoken, &dinfo);

     ALOGE("BSCHANG, IN BOOTANIMATION， getDisplayInfo result=%d!",status);

     mFlingerSurface.clear();
     mFlingerSurfaceControl.clear();

     SurfaceComposerClient::openGlobalTransaction();
//     char* value;
//     property_get("user.orientation", value, "2");
//     int ori = atoi(value);
//     ALOGE("BSCHANG, user.orientation = %d", ori);
//     if (ori == 2) {
//         SurfaceComposerClient::setDisplayProjection(dtoken, DisplayState::eOrientationUnlock, Rect(dinfo.w, dinfo.h), Rect(dinfo.w, dinfo.h));
//     } else if (ori == 1) {
//         SurfaceComposerClient::setDisplayProjection(dtoken, DisplayState::eOrientationUnlock, Rect(dinfo.h, dinfo.w), Rect(dinfo.h, dinfo.w));
//     }
     SurfaceComposerClient::closeGlobalTransaction();
     ALOGE("BSCHANG, IN BOOTANIMATION, unlock orientation");
}

}
