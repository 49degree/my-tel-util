package com.example.gzdx;

import com.example.gzdx.Test;
import android.os.Bundle;
import android.os.Looper;
import android.app.Activity;
import android.view.Menu;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.graphics.PixelFormat;
import android.graphics.ImageFormat;
import android.util.Log;

public class MainActivity extends Activity {
	public static String  TAG = "MainActivity";
	
    private SurfaceView mSurface;
    private SurfaceHolder mSurfaceHolder;
    
    boolean open = false;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mSurface = (SurfaceView)this.findViewById(R.id.main_surface);
		mSurfaceHolder = mSurface.getHolder();
		mSurfaceHolder.addCallback(mSurfaceCallback);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
    /**
     * attach and disattach surface to the lib
     */
	Test test = null;
    private final SurfaceHolder.Callback mSurfaceCallback = new Callback() {
        @Override
        public void surfaceChanged(final SurfaceHolder holder, int format, int width, int height) {
            if(format == PixelFormat.RGBX_8888)
                Log.d(TAG, "Pixel format is RGBX_8888");
            else if(format == PixelFormat.RGB_565)
                Log.d(TAG, "Pixel format is RGB_565");
            else if(format == ImageFormat.YV12)
                Log.d(TAG, "Pixel format is YV12");
            else
                Log.d(TAG, "Pixel format is other/unknown");
            if(!open){
            	new Thread(){
            		public void run(){
            			Log.d(TAG, "beging====================");
            			test = new Test();
            			test.syncSystem(holder);
            			Log.d(TAG, "end====================");
            		}
            	}.start();
            	
            }
            open = true;
            
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
        	
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
        	if(test!=null)
        		test.stopSystem();
        	test= null;
        	open = false;

        } 
    };
}
