package com.iss.vdoor.codecengin;

import android.view.SurfaceHolder;



public class CodecEngin {
	
	
	
	/**闁稿繈鍔戦崕鎾焻濮樻湹澹�*/
	public static final int CHANNEL_ALL = 0;
	/**闁哄牜鍓欏﹢纰滻C闂侇偅宀告禍锟�/
	 * 
	 */
	public static final int CHANNEL_AUDIO_MIC = 1;
	/**闁哄牜鍓欏﹢纰坅mera闂侇偅宀告禍锟�/
	 * 
	 */
	public static final int CHANNEL_VIDEO_CAMERA = 2;
	/**閻庝絻顬冮弻鐔兼閹剁瓔鏆ラ梺顐ｅ哺娴滐拷*/
	public static final int CHANNEL_AUDIO_SINK = 3;
	/**閻庝絻顬冮弻鐔烘喆閸℃侗鏆ラ梺顐ｅ哺娴滐拷*/
	public static final int CHANNEL_VIDEO_SINK = 4;

	static {
		System.loadLibrary("horiphone4VDoor");
	}

	private static CodecEngin instance;

	private CodecEngin() {
	}

	public static CodecEngin getInstance() {
		if (instance == null) {
			instance = new CodecEngin();
		}
		return instance;
	}

	
	public native int setObserver(int handle, CodecEngin observer);

	
	public native int switchVideoOnOff(int handle, int channelID);

	/**
	 * 闁稿繑濞婂Λ鎾蓟閹邦亞顏卞┑顖涘笂缂嶅鏌呭宕囩唴
	 * 
	 * @param handle: 濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @param channelID: 濠殿垱甯婄紞瀣焻濮樺磭鐔匢D
	 * 0 闁稿繈鍔戦崕鎾晬閿燂拷
	 * 1 闁哄牜鍓欏﹢纰滻C闁挎冻鎷�
	 * 2 闁哄牜鍓欏﹢纰坅mera闁挎冻鎷�
	 * 3 閻庝絻顬冮弻鐔兼閹剁瓔鏆ラ柨娑虫嫹
	 * 4 閻庝絻顬冮弻鐔烘喆閸℃侗鏆ラ柨娑虫嫹
	 *
	 */
	public native int switchAudioMute(int handle, int channelID);

	
	public native int sendDTMF(int handle, int keyEvent);

	public native int startChannel(CodecParam param);
	
	
	public native int stopChannel(int handle);
	
	
	/**
	 * 閻犱礁澧介悿鍡涘嫉椤掞拷鍕惧Λ鏉垮椤秶鎲撮崱娑辨殽闁哄嫬澧介妵姘跺矗閸屾稒娈�Set local preview param
	 * 
	 * @param aSurfaceHolder: SurfaceHolder instance.
	 * @param width: SurfaceView width
	 * @param height: SurfaceView heigt
	 *
	 */
	public native int setLocalVideoSurface(int handle, SurfaceHolder mSurfaceHolder, int width, int height);

	/**
	 * Start local preview.
	 *     
	 *
	 */
	//public native int startPreview();

	/**
	 * End local preview.
	 *     
	 *
	 */
	//public native int stopPreview();

	/**
	 * 閻犱礁澧介悿鍡涘箺閸曨偄鍓煎璁规嫹
	* @param c
	*/
	public native int setCamera(int handle, int cameraId);

	//public native int setCamera(int handle, Camera c);

	/**
	 * 闁告瑦鍨块敓浠嬪箺閸曨偄鍓煎璺侯嚟閺侀箖妫冮姀鈩冩闁圭櫢鎷�
	 * @param data
	 * @param size
	 */
	//public native void sendCameraData(byte[] data, int size);

	/**
	 * 閻犱礁澧介悿鍡欙拷閸︻収浼傞悷娆忔椤ｅ爼寮伴崜褋浠涢柛娆忓�閺嗭拷
	 * 
	 * !!!闁告帒娲╅鍥ㄧ▔瀹ュ懎璁查柛鎰〗tivity闁汇劌鍩Create,onResume闁告劕鎳撻惃鐔兼偨椤帞绀夋慨婵勫�濡炰靠urface閺夆晜蓱濠�厾鎮銏犵仴濠殿喖顑呯�锟�	 * !!!闂傚浄鎷烽々锕傚捶閳虹椃rface callback闁汇劌鍩Create闂佹彃鐭傚鎵嫬閸愵亝鏆�
	 * 
	 * @param handle: 濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @param aSurfaceHolder: 闁哄嫬澧介妵姘憋拷閸︻収浼傞悷娆忔椤ｅ爼鎯冮崙绌焤faceHolder閻庣數顢婇挅锟�	 * @param width: 閻庨潧婀遍顒傛喆閸℃侗鏆ラ悗纭呮鐎癸拷
	 * @param height: 閻庨潧婀遍顒傛喆閸℃侗鏆ュΔ鍌浢�锟�	 *
	 */
	public native int setRemoteVideoSurface(int handle, SurfaceHolder mSurfaceHolder, int width, int height);

	/**
	 * 閻熸瑱绠戣ぐ鍌炲箮閹炬潙顎�
	 * @param handle:	濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @return
	 */
	public native int snapshot(int handle);

	/**
	 * 闁兼儳鍢茶ぐ鍥箮閹炬潙顎為柡浣哄瀹擄拷
	 * @param handle
	 * @param pixel
	 * @return
	 */
	public native int getSnapData(int handle, byte[] pixel);

	/**
	 * 閻熸瑱绠戣ぐ鍌氼嚕閿熺瓔娼�闁稿绮嶉娑溿亹閺囩偛鍓�
	 * @param handle:	濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @return
	 */
	@Deprecated
	public native int toggleTakeRecord(int handle);

	/**
	 * 閻熸瑱绠戣ぐ鍌氼嚕閿熺瓔娼楃憸鐗堟礀閸庯拷
	 * @param handle:		濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @param recordSound	闁哄嫷鍨伴幆浣姐亹閺囩偛鐓戝閫涘嵆閻擄拷1 yes, 0 no
	 * @param filename		闁哄倸娲ｅ▎銏ゅ触閿燂拷
	 * @return
	 */
	public native int startTakeRecord(int handle, int recordSound, String filename);

	/**
	 * 閻熸瑱绠戣ぐ鍌炲磻濠婂嫷鍓剧憸鐗堟礀閸庯拷
	 * @param handle:	濠殿垱甯婄紞瀣不閿涘嫭鍊為悗鐢殿攰閽栧嫰宕ｉ妷锔惧姶
	 * @return
	 */
	public native int stopTakeRecord(int handle);
	
	
	
	public native int setLogFlag(int isdolog);

	
	

}
