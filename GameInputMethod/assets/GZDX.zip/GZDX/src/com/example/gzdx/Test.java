package com.example.gzdx;

import android.view.SurfaceHolder;

public class Test {
	public native int syncSystem(SurfaceHolder surfaceHolder);
	public native int stopSystem();
	static {
		System.loadLibrary("GZDX");
	}
}
