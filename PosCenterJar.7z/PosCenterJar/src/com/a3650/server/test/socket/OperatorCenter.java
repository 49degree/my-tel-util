/***********************************************************************
 * Module:  OperatorCenter.java
 * Author:  Administrator
 * Purpose: Defines the Class OperatorCenter
 ***********************************************************************/

package com.a3650.server.test.socket;

import com.a3650.server.bean.CommandBean;
import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.bean.impl.DownLoginBean;
import com.a3650.server.bean.impl.DownSaleBillBean;
import com.a3650.server.bean.impl.UpLoginBean;
import com.a3650.server.bean.impl.UpSaleBillBean;
import com.a3650.server.common.CommandConstant;
import com.a3650.server.common.TypeConversion;
import com.a3650.server.core.CommandControl;

/** @pdOid 137721cf-ea92-4e04-a329-446fe4b62b8b */
public class OperatorCenter implements Runnable {
	public SocketClient client;

	public OperatorCenter(SocketClient client) {
		this.client = client;
	}


	public void run() {
		try {
			//接收POS上传数据（长度（2B不包括长度的2B）+命令体）
			byte[] receiveBuffer = this.client.receiveData();//(receiveBuffer包含数据长度2byte)
			System.out.println("收到报文：" + TypeConversion.byte2hex(receiveBuffer));
			//调用A3650PosCenter.jar中的方法解析数据得到对象
			UpCommandBean upCommandBean = 
				CommandControl.parseUpComand(receiveBuffer);
			//判断接收的数据是否需要业务处理
			if(upCommandBean.getParseErrorCode()!=0){
				//不需要业务处理，则直接返回JAR包中已经构造的数据给POS
				System.out.println("返回报文：" + TypeConversion.byte2hex(upCommandBean.getErrorReturnBuffer()));
				this.client.returnData(upCommandBean.getErrorReturnBuffer());
				return ;
			}
			
			//返回POS数据对象
			DownCommandBean downCommandBean = null;
			//处理业务逻辑（根据命令ID区分不同的业务）
			CommandBean commandBean = upCommandBean.getCommandBean();
			if(CommandConstant.CMD_LOGIN.equals(
					commandBean.getCommandCode())){//登录
				UpLoginBean realBean = (UpLoginBean)upCommandBean;//转换成实际类型
				
				//构造返回对象
				DownLoginBean downLoginBean = new DownLoginBean();
				downLoginBean.setCommandBean(commandBean);
				/*******************************************************************
				 * 以下进行登录业务逻辑处理，登录所需要数据均在UpLoginBean对象中
				 * 处理把需要返回POS的数据放入DownLoginBean对象中
			     *******************************************************************/
				
				downCommandBean = downLoginBean;
				
		    }else if(CommandConstant.CMD_SALE2.equals(
		    		commandBean.getCommandCode())){//售单
		    	UpSaleBillBean realBean = 
		    		(UpSaleBillBean)upCommandBean;//转换成实际类型
		    	//以下进行售单业务逻辑处理，售单所需要数据均在UpSaleBillBean对象中
				//构造返回对象
		    	DownSaleBillBean downSaleBillBean = new DownSaleBillBean();
		    	downSaleBillBean.setCommandBean(commandBean);
				/*******************************************************************
				 * 以下进行登录业务逻辑处理，登录所需要数据均在UpLoginBean对象中
				 * 处理把需要返回POS的数据放入DownLoginBean对象中
			     *******************************************************************/
				downCommandBean = downSaleBillBean;   	
		    	
		    }
			//解析返回POS的对象为字节流
			byte[] sendBuffer = 
				CommandControl.parseDownComand(downCommandBean);
			
			//以下2参数告诉保险公司系统构造解析是否成功，
			//可不用处理直接返回数据sendBuffer
			downCommandBean.getCreateErrorCode();//解析数据结果0=成功，其他失败
			downCommandBean.getCreateErrorMsg();//构造返回失败说明
			//发送数据到POS终端
			System.out.println("返回报文：" + TypeConversion.byte2hex(sendBuffer));
			this.client.returnData(sendBuffer);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			try{
				client.close();
			}catch(Exception e){
				
			}
		}
	}

}