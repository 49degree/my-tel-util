package com.a3650.server.bean;


/**
 * 下行命令实体类，对应有命令头各个属性和命令体
 */
public abstract class DownCommandBean{
	//命令头信息
	private CommandBean commandBean = null;
	// 应答码
	private byte answerCode;
	// 应答消息
	private String answerMsg;
	//构造返回数据失败代码
	private int createErrorCode = 0;//默认为0=成功，其他失败
	//构造返回失败说明
	private String createErrorMsg;

	
	public CommandBean getCommandBean() {
		return commandBean;
	}

	public void setCommandBean(CommandBean commandBean) {
		this.commandBean = commandBean;
	}
	
	public byte getAnswerCode() {
		return answerCode;
	}

	public void setAnswerCode(byte answerCode) {
		this.answerCode = answerCode;
	}

	public String getAnswerMsg() {
		return answerMsg;
	}

	public void setAnswerMsg(String answerMsg) {
		this.answerMsg = answerMsg;
	}

	public int getCreateErrorCode() {
		return createErrorCode;
	}

	public void setCreateErrorCode(int createErrorCode) {
		this.createErrorCode = createErrorCode;
	}

	public String getCreateErrorMsg() {
		return createErrorMsg;
	}

	public void setCreateErrorMsg(String createErrorMsg) {
		this.createErrorMsg = createErrorMsg;
	}
	
	//构造命令体数据
	public abstract byte[] parseBody();
	
	
}
