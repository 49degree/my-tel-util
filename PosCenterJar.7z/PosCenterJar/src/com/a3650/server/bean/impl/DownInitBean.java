package com.a3650.server.bean.impl;

import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.common.TypeConversion;

public class DownInitBean extends DownCommandBean{
//	分公司代码	BranchID	ASC	3	表示本终端所属的分公司的代码
//	终端校验码	ComPSW	ASC	8	终端存储该校验码，以后的通信上报此校验码，与POSID一起验证终端合法性
//	管理员工号(预留)	ManID	ASC	6	终端注册成功后，需要在显示屏上显示该号码，以便管理员参考校对
//	管理员姓名(预留)	ManName	ASC	10	表示对应的管理员的姓名，终端处理同“3-管理员工号”
//	站点名称	StationName	ASC	16	表示本终端所处的站点的名称
//	后台短信接入号码	SMSID	ASC	12	后台短信的接入号码，通过这个后台号码发送的信息，终端会解析显示出来。
	private String branchID;
	private String comPSW;
	private String manID;
	private String manName;
	private String stationName;
	private String sMSID;
	
	
	/**
	 * 封装数据
	 */
	public byte[] parseBody() {
		// TODO Auto-generated method stub
		
		//System.arraycopy(TypeConversion.stringToAscii(downCommandBean.getCommandBean().getCommandCode()), 0, sendByte, 2, 6);//命令码	CommandCode	ASC 	6	具体的命令，应与上行命令相同
		//System.arraycopy(TypeConversion.intToBytes(downCommandBean.getCommandBean().getComSeq()), 0, sendByte, 8, 4);//命令序列	ComSeq	HEX	4	表示该命令的应答序列号，应与上行命令相同
		byte[] buffer = new byte[55];
		try{
			byte[] temp = null;
			if(branchID!=null){
				temp = TypeConversion.stringToAscii(branchID);
				System.arraycopy(temp,0,buffer,0,temp.length>3?3:temp.length);
			}
			if(comPSW!=null){
				temp = TypeConversion.stringToAscii(comPSW);
				System.arraycopy(temp,0,buffer,3,temp.length>8?8:temp.length);
			}
			if(manID!=null){
				temp = TypeConversion.stringToAscii(manID);
				System.arraycopy(temp,0,buffer,11,temp.length>6?6:temp.length);
			}
			if(manName!=null){
				temp = TypeConversion.stringToAscii(manName);
				System.arraycopy(temp,0,buffer,17,temp.length>10?10:temp.length);
			}
			if(stationName!=null){
				temp = TypeConversion.stringToAscii(stationName);
				System.arraycopy(temp,0,buffer,27,temp.length>16?16:temp.length);
			}
			
			if(sMSID!=null){
				temp = TypeConversion.stringToAscii(sMSID);
				System.arraycopy(temp,0,buffer,43,temp.length>12?12:temp.length);
			}
		}catch(Exception e){
			e.printStackTrace();
			
		}
		return buffer;
	}



	public String getBranchID() {
		return branchID;
	}



	public void setBranchID(String branchID) {
		this.branchID = branchID;
	}



	public String getComPSW() {
		return comPSW;
	}



	public void setComPSW(String comPSW) {
		this.comPSW = comPSW;
	}



	public String getManID() {
		return manID;
	}



	public void setManID(String manID) {
		this.manID = manID;
	}



	public String getManName() {
		return manName;
	}



	public void setManName(String manName) {
		this.manName = manName;
	}



	public String getStationName() {
		return stationName;
	}



	public void setStationName(String stationName) {
		this.stationName = stationName;
	}



	public String getsMSID() {
		return sMSID;
	}



	public void setsMSID(String sMSID) {
		this.sMSID = sMSID;
	}
	
	
	
}
