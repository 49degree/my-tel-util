package com.a3650.server.test;

import com.a3650.server.test.socket.SocketServer;


public class Test {
	public static void main(String[] args){
		SocketServer.Context.start();
	}
}
