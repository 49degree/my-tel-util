package com.a3650.server.core;

import com.a3650.server.bean.CommandBean;
import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.bean.impl.DownErrorBean;
import com.a3650.server.bean.impl.DownInitBean;
import com.a3650.server.bean.impl.DownLoginBean;
import com.a3650.server.bean.impl.UpErrorBean;
import com.a3650.server.common.CommandConstant;




/**
 * 命令上传下载控制
 * @author Administrator
 *
 */
public class CommandControl {
	
	/**
	 * 解析上行命令
	 * 
	 * @param upBuffer 服务器收到的POS上传的数据
	 * @return
	 */
	public static UpCommandBean parseUpComand(byte[] upBuffer){
		CommandBean commandBean = null;
		try{
			commandBean = new CommandBean();
			//解析头部
			UpCommandParse upCommandParse = new UpCommandParse(upBuffer);
			upCommandParse.parseCommandHeader(commandBean);
			
			//获取加解密对象
			CryptionControl cryptionControl = createCryptionControl(commandBean);
			//解析命令体
			UpCommandBean upCommandBean = upCommandParse.parseCommandBody(commandBean, cryptionControl);
			
			//判断是否初始化
			if(CommandConstant.CMD_INIT.equals(commandBean.getCommandCode())){
				
				if(true){//测试异常情况
					//throw new CommandParseException("MAC错误");
				}
				return createReturnInitBuffer(upCommandBean);
			}
			return upCommandBean;
		}catch(CommandParseException e){//出现异常，服务器直接返回upErrorBean对象的ErrorReturnBuffer即可
			return createErrorMsg(commandBean,e.getMessage());
		}
	}
	
	
	/**
	 * 
	 * 构造下行数据
	 * 
	 * @param downCommandBean 服务器返回POS的对象
	 * @return
	 */
	public static byte[] parseDownComand(DownCommandBean downCommandBean){
		try{		
			if(CommandConstant.CMD_LOGIN.equals(downCommandBean.getCommandBean().getCommandCode())){//登录
				//创建动态密钥
				((DownLoginBean)downCommandBean).setPsw("11111111");
			}
			
			//获取加解密对象
			CryptionControl cryptionControl = createCryptionControl(downCommandBean.getCommandBean());
			
			DownCommandParse downCommandParse = new DownCommandParse(downCommandBean);
			
			if(true){//测试异常情况
				//throw new CommandParseException("MAC错误11");
			}
			
			byte[] returnBuffer = downCommandParse.getCommandBuffer(cryptionControl);
			return returnBuffer;
		}catch(CommandParseException e){//出现异常，服务器直接返回upErrorBean对象的ErrorReturnBuffer即可
			downCommandBean.setCreateErrorCode(1);
			downCommandBean.setCreateErrorMsg(e.getMessage());
			
			//构造错误返回信息
			DownErrorBean downErrorBean = new DownErrorBean();
			if(downCommandBean==null||downCommandBean.getCommandBean()==null){
				CommandBean commandBean = new CommandBean();
				commandBean.setPosID("        ");
				commandBean.setCommandCode(CommandConstant.CMD_POS_ALARM);
				downErrorBean.setCommandBean(commandBean);
			}else{
				downErrorBean.setCommandBean(downCommandBean.getCommandBean());
			}
			downErrorBean.setAnswerCode((byte)0x10);
			downErrorBean.setAnswerMsg(e.getMessage());
			//获取加解密对象
			CryptionControl cryptionControl = createCryptionControl(downErrorBean.getCommandBean());
			DownCommandParse downCommandParse = new DownCommandParse(downErrorBean);
			try{
				return downCommandParse.getCommandBuffer(cryptionControl);
			}catch(CommandParseException ex){
				return null;
			}
			
		}
	}
	
	/**
	 * 构造返回失败数据(后续增加)
	 * @param errorCode
	 * @param errorMsg
	 * @return
	 */
	private static UpErrorBean createErrorMsg(CommandBean commandBean,String errorMsg){
		//构造错误返回信息
		DownErrorBean downErrorBean = new DownErrorBean();
		if(commandBean==null){
			commandBean = new CommandBean();
			commandBean.setPosID("        ");
			commandBean.setCommandCode(CommandConstant.CMD_POS_ALARM);
			downErrorBean.setCommandBean(commandBean);
		}else{
			downErrorBean.setCommandBean(commandBean);
		}
		downErrorBean.setCommandBean(commandBean);
		downErrorBean.setAnswerCode((byte)(byte)0x10);
		downErrorBean.setAnswerMsg(errorMsg);
		
		byte[] buffer = parseDownComand(downErrorBean);
		
		UpErrorBean upErrorBean = new UpErrorBean();
		upErrorBean.setCommandBean(commandBean);
		upErrorBean.setParseErrorCode(1);//错误
		upErrorBean.setParseErrorMsg(errorMsg);
		upErrorBean.setErrorReturnBuffer(buffer);
		
		return upErrorBean;
	}
	
	
	/**
	 * 根据POS终端加解密对象
	 * @param commandBean
	 * @return
	 */
	private static CryptionControl createCryptionControl(CommandBean commandBean){
		CryptionControl cryptionControl = new CryptionControl(); 
		//构造密钥
		byte[] key = commandBean.getPosID().getBytes();
		
		
		cryptionControl.setDynamicKey(key);
		return cryptionControl; 
	}
	
	/**
	 * 构造初始化数据
	 * @param downInitBean
	 */
	private static UpErrorBean createReturnInitBuffer(UpCommandBean upCommandBean){
		
//		分公司代码	BranchID	ASC	3	表示本终端所属的分公司的代码
//		终端校验码	ComPSW	ASC	8	终端存储该校验码，以后的通信上报此校验码，与POSID一起验证终端合法性
//		管理员工号(预留)	ManID	ASC	6	终端注册成功后，需要在显示屏上显示该号码，以便管理员参考校对
//		管理员姓名(预留)	ManName	ASC	10	表示对应的管理员的姓名，终端处理同“3-管理员工号”
//		站点名称	StationName	ASC	16	表示本终端所处的站点的名称
//		后台短信接入号码	SMSID	ASC	12	后台短信的接入号码，通过这个后台号码发送的信息，终端会解析显示出来。
		
		DownInitBean downInitBean = new DownInitBean();
		downInitBean.setCommandBean(upCommandBean.getCommandBean());
		downInitBean.setBranchID("123");
		downInitBean.setComPSW("11111111");
		downInitBean.setManID("123456");
		downInitBean.setManName("测试工号");
		downInitBean.setStationName("测试站点");
		downInitBean.setsMSID("13800000000");
		downInitBean.setAnswerCode((byte)0x00);
		downInitBean.setAnswerMsg("初始化成功");
		
		byte[] buffer = parseDownComand(downInitBean);
		
		//直接返回初始化数据到POS终端
		UpErrorBean upErrorBean = new UpErrorBean();
		upErrorBean.setCommandBean(upCommandBean.getCommandBean());
		upErrorBean.setParseErrorCode(2);//直接返回
		upErrorBean.setParseErrorMsg("初始化命令，无需业务处理");
		upErrorBean.setErrorReturnBuffer(buffer);
		
		return upErrorBean;

		
	}
	
	
	
}
