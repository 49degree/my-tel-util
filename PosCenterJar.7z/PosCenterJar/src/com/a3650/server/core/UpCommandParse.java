package com.a3650.server.core;

import java.io.UnsupportedEncodingException;

import com.a3650.server.bean.CommandBean;
import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.bean.impl.UpInitBean;
import com.a3650.server.bean.impl.UpLoginBean;
import com.a3650.server.common.CommandConstant;
import com.a3650.server.common.TypeConversion;

/**
 * 下载命令解析
 * 
 * @author Administrator
 * 
 */
public class UpCommandParse {
	private byte[] retutnByte;
	
	private CryptionControl cryptionControl = null; 
	
	/**
	 * 构造函数
	 * @roseuid 4DF8330C030D
	 */
	public UpCommandParse(byte[] retutnByte) throws CommandParseException{
		this.retutnByte = retutnByte;
	}

	/**
	 * 解析上传数据头(请参照协议)
	 * 
	 * @return DownCommandBean
	 * @roseuid 4DF72FB00242
	 */
	public void parseCommandHeader(CommandBean commandBean) throws CommandParseException{
		try{
			//解析命令头
			int cmdLength = retutnByte.length;
			//upCommandBean.setLen(TypeConversion.bytesToShort(retutnByte, 0));//命令长度 Len HEX 2
			commandBean.setCommandCode(TypeConversion.asciiToString(retutnByte, 2, 6));//命令码 CommandCode ASC 6 
			commandBean.setPosID(TypeConversion.asciiToString(retutnByte, 8, 8));//终端ID
			commandBean.setComSeq(TypeConversion.bytesToInt(retutnByte, 16));//命令序列 ComSeq HEX 4 
			byte[] mac = new byte[16];//数字签名	MAC	HEX	16	经过加密计算得到8个字节数字签名，填充前8字节，后8字节预留暂不使用
			System.arraycopy(retutnByte, 20, mac, 0, mac.length);
			//commandBean.setMark(TypeConversion.asciiToString(retutnByte, 36, 20));//保留	Mark	HEX	20	为了以后兼容扩充保留的20个字节，目前统一填写0x20，就是空格。
		}catch(Exception ue){
			throw new CommandParseException("解析数据异常"); 
		}
	}
	
	
	
	/**
	 * 解析上传数据头(请参照协议)
	 * 
	 * @return DownCommandBean
	 * @roseuid 4DF72FB00242
	 */
	public UpCommandBean parseCommandBody(CommandBean commandBean,CryptionControl cryptionControl) throws CommandParseException{
		try{
			//解析命令头
			int cmdLength = retutnByte.length;
			byte[] mac = new byte[8];//数字签名	MAC	HEX	16	经过加密计算得到8个字节数字签名，填充前8字节，后8字节预留暂不使用
			System.arraycopy(retutnByte, 20, mac, 0, mac.length);

			if(cmdLength-69>0){
				//验证数字签名是否正确
				byte[] body = new byte[cmdLength-56];//命令体长度cmdLength-69
				System.arraycopy(retutnByte, 56, body, 0, body.length);
				byte[] tempMac = cryptionControl.getMAC(commandBean.getCommandCode(), body);
				//验证数字签名是否正确,并解密命令体
				if(TypeConversion.bytesToLong(tempMac, 0)==TypeConversion.bytesToLong(mac,0)){//摘要正确
					body =  cryptionControl.getFormerData(commandBean.getCommandCode(), body);//解密数据
					/**********************以下根据命令码解析成相应对象************************************************************************/
					UpCommandBean upCommandBean = null;
					if(CommandConstant.CMD_INIT.equals(commandBean.getCommandCode())){//初始化
						upCommandBean = new UpInitBean();
					}else if(CommandConstant.CMD_LOGIN.equals(commandBean.getCommandCode())){//登录
						upCommandBean = new UpLoginBean();
				    }
					/**********************************************请添加其他*******************************************************************/
					
					upCommandBean.setCommandBean(commandBean);
					upCommandBean.parseBody(body);
					return upCommandBean;
				}else{
					throw new CommandParseException("MAC错误");
				}
			}else{
				throw new CommandParseException("数据长度错误");
			}
			
		}catch(Exception ue){
			throw new CommandParseException("解析数据异常"); 
		}
	}

	public byte[] getRetutnByte() {
		return retutnByte;
	}
}
