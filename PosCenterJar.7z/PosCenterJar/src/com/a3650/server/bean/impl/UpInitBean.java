package com.a3650.server.bean.impl;

import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.common.TypeConversion;

public class UpInitBean extends UpCommandBean{
//	1	终端ID	PosID	ASC	8	
//	2	终端初始化注册码	InitPSW	ASC	8	终端初始化的时候后台分配的注册码
//	3	SIM卡号码	SIMCode	ASC	12	表示终端安装的SIM卡的号码
//	4	当前软件版本号	CurSoftVer	ASC	20	终端必须把软件版本发到后台
//	5	当前硬件版本	CurHardVer	ASC	20	当前硬件版本号
	private String posId;
	private String initPSW ;
	private String simNo;
	private String curSoftVer;
	private String curHardVer;
	

	public void parseBody(byte[] body) {
		// TODO Auto-generated method stub
		try{
			this.setPosId(TypeConversion.asciiToString(body, 0, 8).trim());
			this.setInitPSW(TypeConversion.asciiToString(body, 8, 8).trim());
			this.setSimNo(TypeConversion.asciiToString(body, 16,12).trim());//命令序列 ComSeq HEX 4 
			this.setCurSoftVer(TypeConversion.asciiToString(body, 28,20).trim());
			this.setCurHardVer(TypeConversion.asciiToString(body, 48,20).trim());
		}catch(Exception e){
			
		}


	}


	public String getPosId() {
		return posId;
	}


	public void setPosId(String posId) {
		this.posId = posId;
	}


	public String getInitPSW() {
		return initPSW;
	}


	public void setInitPSW(String initPSW) {
		this.initPSW = initPSW;
	}


	public String getSimNo() {
		return simNo;
	}


	public void setSimNo(String simNo) {
		this.simNo = simNo;
	}


	public String getCurSoftVer() {
		return curSoftVer;
	}


	public void setCurSoftVer(String curSoftVer) {
		this.curSoftVer = curSoftVer;
	}


	public String getCurHardVer() {
		return curHardVer;
	}


	public void setCurHardVer(String curHardVer) {
		this.curHardVer = curHardVer;
	}
	
	
	
}
