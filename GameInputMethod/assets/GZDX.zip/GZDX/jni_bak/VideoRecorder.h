/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef VIDEO_RECORDER_H_

#define VIDEO_RECORDER_H_

#include <media/MediaRecorderBase.h>
#include <camera/CameraParameters.h>
//#include <utils/String8.h>

namespace android {

class Camera;
class ICameraRecordingProxy;
class CameraSource;
class CameraSourceTimeLapse;
struct MediaSource;
struct MediaWriter;
class MetaData;
struct AudioSource;
class MediaProfiles;
class ISurfaceTexture;
class SurfaceMediaSource;

struct VideoRecorder: public RefBase {
public:
	VideoRecorder();
	virtual ~VideoRecorder();

	status_t init();
	//status_t setAudioSource(audio_source as);
	//status_t setVideoSource(video_source vs);
	//status_t setOutputFormat(output_format of);
	//status_t setAudioEncoder(audio_encoder ae);
	status_t setVideoEncoder(video_encoder ve);
	status_t setVideoSize(int width, int height);
	status_t setVideoFrameRate(int frames_per_second);
	status_t setParamVideoEncodingBitRate(int32_t bitRate);
	status_t setParamVideoIFramesInterval(int32_t seconds);
	status_t setParamVideoEncoderProfile(int32_t profile);
	status_t setParamVideoEncoderLevel(int32_t level);
	//status_t setCamera(const sp<ICamera>& camera);
	status_t setPreviewSurface(const sp<Surface>& surface);
	//status_t setOutputFile(const char *path);
	//status_t setOutputFile(int fd, int64_t offset, int64_t length);
	status_t setParameters(const String8 & params);
	status_t setListener(const sp<IMediaRecorderClient>& listener);
	status_t prepare();
	status_t start();
	status_t pause();
	status_t stop();
	status_t close();
	status_t reset();
	//status_t getMaxAmplitude(int *max);
	status_t dump();
	//virtual status_t dump(int fd, const Vector<String16>& args) const;
	//sp<ISurfaceTexture> querySurfaceMediaSource() const;

	status_t setParamVideoCameraId(int32_t cameraId);

	status_t setupConn(int videoSocket, const char *remoteIp, int remoteVideoPort,int playload);

private:

	enum CameraFlags {
		FLAGS_SET_CAMERA = 1L << 0, FLAGS_HOT_CAMERA = 1L << 1,
	};

	int mPlayload;

	bool mBinded; //´©Í¸ÊÇ·ñ³É¹¦
	bool mStarted; //ÒÑ¾­µã»÷²¥·Å
	int mVideoSocket; //add
	const char *mRemoteIp; //add
	int mRemoteVideoPort; // add

	sp<ICamera> mCamera;
	sp<ICameraRecordingProxy> mCameraProxy;
	sp<Surface> mPreviewSurface;
	sp<IMediaRecorderClient> mListener;
	sp<MediaWriter> mWriter;
	int mOutputFd;
	//sp<AudioSource> mAudioSourceNode;

	//audio_source_t mAudioSource;
	video_source mVideoSource;
	output_format mOutputFormat;
	//audio_encoder mAudioEncoder;
	video_encoder mVideoEncoder;
	bool mUse64BitFileOffset;
	int32_t mVideoWidth, mVideoHeight;
	int32_t mFrameRate;
	int32_t mVideoBitRate;
	//int32_t mAudioBitRate;
	//int32_t mAudioChannels;
	//int32_t mSampleRate;
	int32_t mInterleaveDurationUs;
	int32_t mIFramesIntervalSec;
	int32_t mCameraId;
	int32_t mVideoEncoderProfile;
	int32_t mVideoEncoderLevel;
	int32_t mMovieTimeScale;
	int32_t mVideoTimeScale;
	//int32_t mAudioTimeScale;
	int64_t mMaxFileSizeBytes;
	int64_t mMaxFileDurationUs;
	int64_t mTrackEveryTimeDurationUs;
	int32_t mRotationDegrees; // Clockwise
	int32_t mLatitudex10000;
	int32_t mLongitudex10000;
	int32_t mStartTimeOffsetMs;

	bool mCaptureTimeLapse;
	int64_t mTimeBetweenTimeLapseFrameCaptureUs;
	sp<CameraSourceTimeLapse> mCameraSourceTimeLapse;

	String8 mParams;

	bool mIsMetaDataStoredInVideoBuffers;
	MediaProfiles *mEncoderProfiles;

	//bool mStarted;
	// Needed when GLFrames are encoded.
	// An <ISurfaceTexture> pointer
	// will be sent to the client side using which the
	// frame buffers will be queued and dequeued
	//sp<SurfaceMediaSource> mSurfaceMediaSource;

	/*status_t setupMPEG4Recording(
	 int outputFd,
	 int32_t videoWidth, int32_t videoHeight,
	 int32_t videoBitRate,
	 int32_t *totalBitRate,
	 sp<MediaWriter> *mediaWriter);*/
	/*void setupMPEG4MetaData(int64_t startTimeUs, int32_t totalBitRate,
	 sp<MetaData> *meta);
	 status_t startMPEG4Recording();
	 status_t startAMRRecording();
	 status_t startAACRecording();
	 status_t startRawAudioRecording();*/
	status_t startRTPRecording();
	//status_t startMPEG2TSRecording();
	//sp<MediaSource> createAudioSource();
	status_t checkVideoEncoderCapabilities();
	//status_t checkAudioEncoderCapabilities();
	// Generic MediaSource set-up. Returns the appropriate
	// source (CameraSource or SurfaceMediaSource)
	// depending on the videosource type
	status_t setupMediaSource(sp<MediaSource> *mediaSource);
	status_t setupCameraSource(sp<CameraSource> *cameraSource);
	// setup the surfacemediasource for the encoder
	status_t setupSurfaceMediaSource();

	//status_t setupAudioEncoder(const sp<MediaWriter>& writer);
	status_t setupVideoEncoder(sp<MediaSource> cameraSource, int32_t videoBitRate, sp<MediaSource> *source);

	// Encoding parameter handling utilities
	status_t setParameter(const String8 &key, const String8 &value);
	//status_t setParamAudioEncodingBitRate(int32_t bitRate);
	//status_t setParamAudioNumberOfChannels(int32_t channles);
	//status_t setParamAudioSamplingRate(int32_t sampleRate);
	//status_t setParamAudioTimeScale(int32_t timeScale);
	status_t setParamTimeLapseEnable(int32_t timeLapseEnable);
	status_t setParamTimeBetweenTimeLapseFrameCapture(int64_t timeUs);

	//status_t setParamVideoCameraId(int32_t cameraId);
	status_t setParamVideoTimeScale(int32_t timeScale);
	status_t setParamVideoRotation(int32_t degrees);
	status_t setParamTrackTimeStatus(int64_t timeDurationUs);
	status_t setParamInterleaveDuration(int32_t durationUs);
	status_t setParam64BitFileOffset(bool use64BitFileOffset);
	//status_t setParamMaxFileDurationUs(int64_t timeUs);
	//status_t setParamMaxFileSizeBytes(int64_t bytes);
	status_t setParamMovieTimeScale(int32_t timeScale);
	status_t setParamGeoDataLongitude(int64_t longitudex10000);
	status_t setParamGeoDataLatitude(int64_t latitudex10000);
	void clipVideoBitRate();
	void clipVideoFrameRate();
	void clipVideoFrameWidth();
	void clipVideoFrameHeight();
	//void clipAudioBitRate();
	//void clipAudioSampleRate();
	//void clipNumberOfAudioChannels();
	void setDefaultProfileIfNecessary();

	VideoRecorder(const VideoRecorder &);
	VideoRecorder &operator=(const VideoRecorder &);
};

} // namespace android

#endif  // STAGEFRIGHT_RECORDER_H_
