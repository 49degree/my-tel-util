#include <string.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <android_runtime/AndroidRuntime.h>

//#include "BasicTypes.h"
//#include "HoriPhoneAudio.h"
#include "HoriPhoneVideo.h"
#include "HoriPhoneRecorder.h"
//#include "log.h"

//#include "LocalSource.h"


using namespace android;


#define LOG_TAG "MediaControl"



/************参数设置**********************/


HoriPhoneAudio* pHoriPhoneAudioList[MAX_PHONE_INSTANCE] = {NULL};   //音频控制器对象实例列表
HoriPhoneVideo* pHoriPhoneVideoList[MAX_PHONE_INSTANCE] = {NULL};   //视频控制器对象实例列表


const char* MEDIA_DIR_STR[] = {"inactive", "recvonly", "sendonly", "sendrecv"};
const char* DTMF_BAND_STR[] = {"outband", "inband"};
const char* VIDEO_RESOLUTION_STR[] = {"CIF", "QCIF","4CIF"};


Mutex mMediaLock;    //媒体操作线程锁，用于同步各媒体操作，以免发生崩溃



int activeInstances; //当前使用的实例数

extern sp<Camera> get_native_camera(JNIEnv *env, jobject thiz, struct JNICameraContext** context);


//记录当前生成的recorder对象指针
//用于释放
HoriPhoneRecorder * pHoriPhoneRecorder;


int parseMediaParam(JNIEnv *env, jobject thiz, jobject param, AudioParam * ap, VideoParam *vp)
{
	jclass clazz = env->GetObjectClass(param);
	if (!clazz) {
		LOG_E(LOG_TAG, "Fail to call GetObjectClass in %s", __FUNCTION__);
		return STATUS_INVALID_PARAM;
	}

	jfieldID fieldID;
	jstring jstr;
	const char * str;
	

	//---------------------
	//Public parameters zone
	//---------------------

	//localIP
	fieldID = env->GetFieldID(clazz, "localIP", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of localIP");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(ap->localIP, str, sizeof(ap->localIP) - 1);
	strncpy(vp->localIP, str, sizeof(vp->localIP) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[public param]localIP = %s", ap->localIP);

	//localSessionid
	fieldID = env->GetFieldID(clazz, "localSessionid", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of localSessionid");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(ap->localSessionid, str, sizeof(ap->localSessionid) - 1);
	strncpy(vp->localSessionid, str, sizeof(vp->localSessionid) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[public param]localSessionid = %s", ap->localSessionid);

	//remoteSessionid
	fieldID = env->GetFieldID(clazz, "remoteSessionid", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteSessionid");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(ap->remoteSessionid, str, sizeof(ap->remoteSessionid) - 1);
	strncpy(vp->remoteSessionid, str, sizeof(vp->remoteSessionid) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[public param]remoteSessionid = %s", ap->remoteSessionid);
	
	

	//---------------------
	//Audio parameters zone
	//---------------------

	//remoteAudioIP
	fieldID = env->GetFieldID(clazz, "remoteAudioIP", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteIP");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(ap->remoteIP, str, sizeof(ap->remoteIP) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[audio param]remoteAudioIP = %s", ap->remoteIP);

		

	//localAudioPort
	fieldID = env->GetFieldID(clazz, "localAudioPort", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of localAudioPort");
		return STATUS_INVALID_PARAM;
	}
	ap->localAudioPort = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]localAudioPort=%d", ap->localAudioPort);

	//remoteAudioPort
	fieldID = env->GetFieldID(clazz, "remoteAudioPort", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteAudioPort");
		return STATUS_INVALID_PARAM;
	}
	ap->remoteAudioPort = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]remoteAudioPort=%d", ap->remoteAudioPort);


	//audioPayloadName
	fieldID = env->GetFieldID(clazz, "audioPayloadName", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteSessionid");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(ap->audioPayloadName, str, sizeof(ap->audioPayloadName) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[audio param]audioPayloadName = %s", ap->audioPayloadName);



	//audioPayloadID
	fieldID = env->GetFieldID(clazz, "audioPayloadID", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of audioPayload");
		return STATUS_INVALID_PARAM;
	}
	ap->audioPayloadID = env->GetIntField(param, fieldID);
	//ap->audioPayloadID=18;
	if(-1==ap->audioPayloadID)
		ap->audioPayloadID=18;
	LOG_V(LOG_TAG, "[audio param]audioPayloadID=%d", ap->audioPayloadID);


	//packettime
	fieldID = env->GetFieldID(clazz, "packettime", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of packettime");
		return STATUS_INVALID_PARAM;
	}
	ap->packettime = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]packettime=%d", ap->packettime);


	//dtmfInband
	fieldID = env->GetFieldID(clazz, "dtmfBand", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of dtmfBand");
		return STATUS_INVALID_PARAM;
	}
	ap->dtmfBand = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]dtmfBand=%s", DTMF_BAND_STR[ap->dtmfBand]);

	//dtmfPayloadID
	fieldID = env->GetFieldID(clazz, "dtmfPayloadID", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of dtmfPayloadID");
		return STATUS_INVALID_PARAM;
	}
	ap->dtmfPayloadID = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]dtmfPayloadID=%d", ap->dtmfPayloadID);

	
	//audioDirect
	fieldID = env->GetFieldID(clazz, "audioDirect", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of audioDirect");
		return STATUS_INVALID_PARAM;
	}
	ap->audioDirect = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[audio param]audioDirect=%s", MEDIA_DIR_STR[ap->audioDirect]);



	//---------------------
	//Video parameters zone
	//---------------------

	//remoteAudioIP
	fieldID = env->GetFieldID(clazz, "remoteVideoIP", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteVideoIP");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(vp->remoteIP, str, sizeof(vp->remoteIP) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[video param]remoteVideoIP = %s", vp->remoteIP);

	//localVideoPort
	fieldID = env->GetFieldID(clazz, "localVideoPort", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of localVideoPort");
		return STATUS_INVALID_PARAM;
	}
	vp->localVideoPort = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]localVideoPort=%d", vp->localVideoPort);
	
	

	//remoteVideoPort
	fieldID = env->GetFieldID(clazz, "remoteVideoPort", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteVideoPort");
		return STATUS_INVALID_PARAM;
	}
	vp->remoteVideoPort = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]remoteVideoPort=%d", vp->remoteVideoPort);


	
	//videoPayloadName
	fieldID = env->GetFieldID(clazz, "videoPayloadName", "Ljava/lang/String;");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of remoteSessionid");
		return STATUS_INVALID_PARAM;
	}
	jstr = (jstring) env->GetObjectField(param, fieldID);
	str = env->GetStringUTFChars(jstr, JNI_FALSE);
	strncpy(vp->videoPayloadName, str, sizeof(vp->videoPayloadName) - 1);
	env->ReleaseStringUTFChars(jstr, str);
	LOG_V(LOG_TAG, "[video param]videoPayloadName = %s", vp->videoPayloadName);

	

	//videoPayloadID
	fieldID = env->GetFieldID(clazz, "videoPayloadID", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of videoPayloadID");
		return STATUS_INVALID_PARAM;
	}
	vp->videoPayloadID = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]videoPayloadID=%d", vp->videoPayloadID);

	
	//bitRate
	fieldID = env->GetFieldID(clazz, "bitRate", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of bitRate");
		return STATUS_INVALID_PARAM;
	}
	vp->bitRate = env->GetIntField(param, fieldID);
	vp->bitRate *= 1000;
	
	LOG_V(LOG_TAG, "[video param]bitRate=%d", vp->bitRate);

	//mode
	fieldID = env->GetFieldID(clazz, "mode", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of mode");
		return STATUS_INVALID_PARAM;
	}
	vp->mode = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]mode=%d", vp->mode);

	//resolution
	fieldID = env->GetFieldID(clazz, "resolution", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of resolution");
		return STATUS_INVALID_PARAM;
	}
	vp->resolution = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]resolution=%s", VIDEO_RESOLUTION_STR[vp->resolution-1]);

	//videoWidth
	fieldID = env->GetFieldID(clazz, "videoWidth", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of videoWidth");
		return STATUS_INVALID_PARAM;
	}
	vp->videoWidth = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]videoWidth=%d", vp->videoWidth);

	//videoHeight
	fieldID = env->GetFieldID(clazz, "videoHeight", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of videoHeight");
		return STATUS_INVALID_PARAM;
	}
	vp->videoHeight = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]videoHeight=%d", vp->videoHeight);

	
	//frameRate
	fieldID = env->GetFieldID(clazz, "frameRate", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of frameRate");
		return STATUS_INVALID_PARAM;
	}
	vp->frameRate = env->GetIntField(param, fieldID);
	if(vp->frameRate > 15)
	{
		vp->frameRate = 15;
	}
   	
	LOG_V(LOG_TAG, "[video param]frameRate=%d", vp->frameRate);

	//H264Level
	fieldID = env->GetFieldID(clazz, "H264Level", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of H264Level");
		return STATUS_INVALID_PARAM;
	}
	vp->H264Level = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]H264Level=%d", vp->H264Level);

	//videoDirect
	fieldID = env->GetFieldID(clazz, "videoDirect", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of videoDirect");
		return STATUS_INVALID_PARAM;
	}
	vp->videoDirect = env->GetIntField(param, fieldID);
	LOG_V(LOG_TAG, "[video param]videoDirect=%s", MEDIA_DIR_STR[vp->videoDirect]);

	

	return STATUS_SUCCESS;


}


void* audioChannelOpenThreadFunc(void * arg)
{
	int ret;

	Mutex::Autolock autoLock(mMediaLock);
	LOG_E(LOG_TAG, "audioChannelOpenThreadFunc get the mMediaLock");
	//LOG_D(LOG_TAG, "Now begin audioChannelOpenThread...");

	AudioParam  *pParam = (AudioParam *)arg;
	int handle = pParam->handle;
	HoriPhoneAudio* pAudio = pHoriPhoneAudioList[handle];
	LOG_D(LOG_TAG, "Now begin audioChannelOpenThread...%d",handle);

	//LOG_E(LOG_TAG, "Audio channel handle is %d, HoriPhoneAudio object is 0x%08x", handle);

	if(pAudio != NULL&&handle!=-1)
	{
		if(true== pAudio->CompareParam(pParam))
		{
			LOG_D(LOG_TAG, "All parameters are the same with current Audio handle %d, so do nothing.", handle);		
			return NULL;
		}

		LOG_D(LOG_TAG, "There are audio parameters different on audio handle %d, so close current audio handle %d first", handle, handle);
		ret = pAudio->Stop();
		delete pHoriPhoneAudioList[handle];
		pHoriPhoneAudioList[handle] = NULL;

		LOG_D(LOG_TAG, "Audio handle %d is stopped and deleted.", handle);
		
	}
	else
	{
		//stop all other in-use audio handle 
		for(int i=0; i<MAX_PHONE_INSTANCE; i++)
		{
			pAudio = pHoriPhoneAudioList[i];
			if(pAudio != NULL)
			{
				LOG_D(LOG_TAG, "Stop audio channel %d.", i);
				ret = pAudio->Stop();
				delete pHoriPhoneAudioList[i];
				pHoriPhoneAudioList[i] = NULL;
				LOG_D(LOG_TAG, "Audio handle %d is stopped and deleted.", i);
			}
		}
	}

	//if there is no audio parameter, just close the handle and do not open it
	if(pParam->localAudioPort <= 0 || pParam->remoteAudioPort <= 0)
	{
		LOG_D(LOG_TAG, "No audio paramters in this command, so do not open the handle.");
		return NULL;
	}


	//Open Audio handle
	LOG_D(LOG_TAG, "Now begin to open and start audio channel %d.", handle);
	pAudio = new HoriPhoneAudio;
	if (NULL == pAudio) {
		LOG_E(LOG_TAG, "Allocate memory for HoriPhoneAudio instance failed !\n");
		return NULL;
	}
	pHoriPhoneAudioList[handle] = pAudio;


	//Set parameter to SIPPhone
	ret = pAudio->SetParameter(pParam);

	ret = pAudio->Prepare();
	if(ret != 1)
	{
		LOG_E(LOG_TAG, "Prepare for  audio handle %d failed, ret=%d.", handle, ret);
		return &ret;
	}

	ret = pAudio->Start();

	return NULL;
	
	

}



void * videoChannelOpenThreadFunc(void* arg)
{
	int ret;

	Mutex::Autolock autoLock(mMediaLock);
	LOG_E(LOG_TAG, "videoChannelOpenThreadFunc get the mMediaLock");

	//LOG_D(LOG_TAG, "Now begin videoChannelOpenThread...");

	VideoParam  *pParam = (VideoParam *)arg;
	int handle = pParam->handle;
	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];

	LOG_D(LOG_TAG, "Now begin videoChannelOpenThread... %d",handle);
	if(pVideo != NULL&&handle!=-1)
	{
		if(true== pVideo->CompareParam(pParam))
		{
			LOG_D(LOG_TAG, "All parameters are the same with current Video handle %d, so do nothing.", handle);		
			return NULL;
		}

		LOG_D(LOG_TAG, "There are video parameters different on video handle %d, so close current video handle %d first", handle, handle);
		ret = pVideo->Stop();
		delete pHoriPhoneVideoList[handle];
		pHoriPhoneVideoList[handle] = NULL;

		LOG_D(LOG_TAG, "Video handle %d is stopped and deleted.", handle);
		
	}
	else
	{
		//stop all other in-use audio handle 
		for(int i=0; i<MAX_PHONE_INSTANCE; i++)
		{
			pVideo = pHoriPhoneVideoList[i];
			if(pVideo != NULL)
			{
				ret = pVideo->Stop();
				delete pHoriPhoneVideoList[i];
				pHoriPhoneVideoList[i] = NULL;
				LOG_D(LOG_TAG, "Video handle %d is stopped and deleted.", i);
			}
		}
	}

	//if there is no audio parameter, just close the handle and do not open it
	if(pParam->localVideoPort<= 0 || pParam->remoteVideoPort<= 0)
	{
		LOG_D(LOG_TAG, "No video paramters in this command, so do not open the handle.");
		return NULL;
	}
	LOG_D(LOG_TAG, "pParam->videoPayloadName is %s",pParam->videoPayloadName);
	if(!strcmp(pParam->videoPayloadName,"H.263"))
	{
		LOG_D(LOG_TAG, "not sport H263 so not start video.");
		return NULL;
	}

	
	//Open Audio handle
	LOG_D(LOG_TAG, "Now begin to open and start video channel %d.", handle);
	pVideo = new HoriPhoneVideo();
	if (NULL == pVideo) {
		LOG_E(LOG_TAG, "Allocate memory for HoriPhoneAudio instance failed !\n");
		return NULL;
	}
	pHoriPhoneVideoList[handle] = pVideo;

	//Set parameter to SIPPhone
	ret = pVideo->SetParameter(pParam);

	ret = pVideo->Prepare();
	if(ret != 1)
	{
		LOG_E(LOG_TAG, "Prepare for video handle %d failed, ret=%d.", handle, ret);
		return &ret;
	}

	ret = pVideo->Start();

	return NULL;


	
}



/************JNI方法开始**********************/


//=========================================================================
// Description : 开始一个媒体话路处理
//=========================================================================
static int startChannel(JNIEnv *env, jobject thiz, jobject param)
{

	int ret = 0;

	LOG_D(LOG_TAG, "Now begin to start channel.\n");
	int handle = -1;

	jclass clazz = env->GetObjectClass(param);
	if (!clazz) {
		LOG_E(LOG_TAG, "Fail to call GetObjectClass in %s", __FUNCTION__);
		return STATUS_INVALID_PARAM;
	}

	//Get handle in PhoneParam(JAVA)
	jfieldID fieldID = env->GetFieldID(clazz, "handle", "I");
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of handle");
		return STATUS_INVALID_PARAM;
	}

	handle = env->GetIntField(param, fieldID);
	LOG_D(LOG_TAG, "Get media andle %d", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid handle value, handle=%d.\n", handle);
		return STATUS_INVALID_PARAM;
	}

	AudioParam  aParam;
	VideoParam  vParam;
	//memset(&aParam, 0, sizeof(aParam));
	//memset(&vParam, 0, sizeof(vParam));

	aParam.handle = handle;
	vParam.handle = handle;
	
	ret = parseMediaParam(env, thiz, param, &aParam, &vParam);
	if(ret == STATUS_INVALID_PARAM)
	{
		LOG_E(LOG_TAG, "Meet invalid param while taking params from jni interface.");
		return -1;
	}

	pthread_t vd_thrd;
	pthread_create(&vd_thrd, NULL, videoChannelOpenThreadFunc, &vParam);

	pthread_t ad_thrd;
	pthread_create(&ad_thrd, NULL, audioChannelOpenThreadFunc, &aParam);

	pthread_join(vd_thrd, NULL);
	pthread_join(ad_thrd, NULL);
	


	return ret;


}


static int stopChannel(JNIEnv *env, jobject thiz, int handle)
{

	Mutex::Autolock autoLock(mMediaLock);
	LOG_E(LOG_TAG, "stopChannel get the mMediaLock");

	LOG_D(LOG_TAG, "Now stop channel %d", handle);

	int ret;

	if (-1!=handle&&(handle < 0 || handle > MAX_PHONE_INSTANCE)) {
		LOG_E(LOG_TAG, "Invalid handle value, handle=%d\n",handle);
		return STATUS_INVALID_PARAM;
	}
	if(-1==handle)
	{
		for(int i=0;i<MAX_PHONE_INSTANCE;i++)
		{
			HoriPhoneAudio* pAudio = pHoriPhoneAudioList[i];
			if(pAudio != NULL)
			{		
				int ret = pAudio->Stop();
				delete pHoriPhoneAudioList[i];
				pHoriPhoneAudioList[i] = NULL;

				LOG_D(LOG_TAG, "-1==handle Audio handle %d is stopped and deleted.", i);
			}

			HoriPhoneVideo* pVideo = pHoriPhoneVideoList[i];
			if(pVideo != NULL)
			{
				ret = pVideo->Stop();
				delete pHoriPhoneVideoList[i];
				pHoriPhoneVideoList[i] = NULL;

				LOG_D(LOG_TAG, "-1==handle Video handle %d is stopped and deleted.", i);
			}

		}
	}
	else
	{
		HoriPhoneAudio* pAudio = pHoriPhoneAudioList[handle];
		if(pAudio != NULL)
		{		
			int ret = pAudio->Stop();
			delete pHoriPhoneAudioList[handle];
			pHoriPhoneAudioList[handle] = NULL;

			LOG_D(LOG_TAG, "Audio handle %d is stopped and deleted.", handle);
		}

		HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
		if(pVideo != NULL)
		{
			ret = pVideo->Stop();
			delete pHoriPhoneVideoList[handle];
			pHoriPhoneVideoList[handle] = NULL;

			LOG_D(LOG_TAG, "Video handle %d is stopped and deleted.", handle);
		}

	}
	
	
	return ret;

}



static int setObserver(JNIEnv *env, jobject thiz, int handle, jobject observer) {
	return 0;
}

//=========================================================================
// Description : 开始对端视频的预览，主要用于门口对讲视频先于音频
//=========================================================================

static int startRemotePreview(JNIEnv *env, jobject thiz, int handle) {

	LOG_D(LOG_TAG, "Start remote preview");
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	int ret;
 /*	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
	if(pVideo != NULL)
	{
		ret = pVideo->startRemotePreview();
	}
     */
	return ret;
}

//=========================================================================
// Description : 启用其中一条通道
//=========================================================================

static int switchVideoOnOff(JNIEnv *env, jobject thiz, int handle, int channelID) {

	LOG_D(LOG_TAG, "switchVideoOnOff on handle %d with operation %d", handle, channelID);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	int ret;
	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
	if(pVideo != NULL)
	{
		ret = pVideo->SwitchVideoOnOff(channelID);
	}

	return ret;
}

//=========================================================================
// Description : 禁用其中一条通道
//=========================================================================

static int switchAudioMute(JNIEnv *env, jobject thiz, int handle, int channelID) {

	LOG_D(LOG_TAG, "switchAudioMute on handle %d with operation %d", handle, channelID);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	int ret;
	
	HoriPhoneAudio* pAudio = pHoriPhoneAudioList[handle];
	if(pAudio != NULL)
	{		
		ret = pAudio->SwitchMute(channelID);
	}

	return ret;
}


//=========================================================================
// Description : 以dtmf方式发送一个按键提示
//=========================================================================

static int sendDTMF(JNIEnv *env, jobject thiz, int handle, int keyValue) {

	LOG_D(LOG_TAG, "SendDTMF on handle %d, key=%d", handle, keyValue);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	int ret;
	HoriPhoneAudio* pAudio = pHoriPhoneAudioList[handle];
	if(pAudio != NULL)
	{		
		ret = pAudio->sendDTMF(keyValue);
	}

	return ret;
}


/*static int setCamera(JNIEnv* env, jobject thiz, int handle, jobject camera) {
 LOG_V(LOG_TAG, "Enter %s()", __FUNCTION__);
 if (handle < 0 || handle > MAX_PHONE_INSTANCE || NULL == instances[handle]) {
 LOG_E(LOG_TAG, "Invalid parameters\n");
 return STATUS_INVALID_PARAM;
 }
 // we should not pass a null camera to get_native_camera() call.
 if (camera == NULL) {
 //jniThrowNullPointerException(env, "camera object is a NULL pointer");
 return 0;
 }
 sp < Camera > c = get_native_camera(env, camera, NULL);
 HoriPhone* phone = instances[handle];
 phone->setCamera(c->remote());
 return 1;
 }*/

static int setCamera(JNIEnv* env, jobject thiz, int handle, int camera) {

	LOG_D(LOG_TAG, "Se camera for handle %d, deviceID=%d", handle, camera);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}
	if (camera < 0) {
		LOG_E(LOG_TAG,"Invalid camera ID %d.", camera);
		return 0;
	}


	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
	if(pVideo != NULL)
	{
		pVideo->setCamera(camera);
	}
	
	return 1;
}

static int setLocalVideoSurface(JNIEnv *env, jobject thiz, int handle, jobject surfaceHolder, int width, int height) {

	LOG_D(LOG_TAG, "Set local video surface for handle %d", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	//Get Surface object of SurfaceHolder
	jclass clazz = env->GetObjectClass(surfaceHolder);
	jmethodID methodID = env->GetMethodID(clazz, "getSurface", "()Landroid/view/Surface;");
	if (NULL == methodID) {
		LOG_E(LOG_TAG, "Fail to call GetMethodID getSurface");
		return STATUS_INVALID_PARAM;
	}

	jobject surfaceObj = env->CallObjectMethod(surfaceHolder, methodID);
	clazz = env->GetObjectClass(surfaceObj);
	if (NULL == clazz) {
		LOG_E(LOG_TAG, "Fail to get GetObjectClass of surfaceObj");
		return STATUS_INVALID_PARAM;
	}
	jfieldID fieldID = env->GetFieldID(clazz, "mNativeObject", "I");//mNativeSurface
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of mSurface");
		return STATUS_INVALID_PARAM;
	}

	LOG_D(LOG_TAG, "Local surfaceObj=%d,fieldID=%d", surfaceObj, fieldID);

	Surface * const p = (Surface*) env->GetIntField(surfaceObj, fieldID);
	if (NULL == p) {
		LOG_E(LOG_TAG, "Fail to GetIntField of surface");
		return STATUS_INVALID_PARAM;
	}


	Mutex::Autolock autoLock(mMediaLock);
	LOG_E(LOG_TAG, "setLocalVideoSurface get the mMediaLock");
	int ret;
	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
	if(pVideo != NULL)
	{
		ret = pVideo->setLocalSurface(p);;
	}
	else
	{
		LOG_E(LOG_TAG, "Video handle is not set, failed to set local surface to handle %d", handle);
	}

	return ret;
}

static int setRemoteVideoSurface(JNIEnv *env, jobject thiz, int handle, jobject surfaceHolder, int width, int height) {

	LOG_D(LOG_TAG, "Set remote video surface for handle %d", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	//Get Surface object of SurfaceHolder
	jclass clazz = env->GetObjectClass(surfaceHolder);
	jmethodID methodID = env->GetMethodID(clazz, "getSurface", "()Landroid/view/Surface;");
	if (NULL == methodID) {
		LOG_E(LOG_TAG, "Fail to call GetMethodID getSurface");
		return STATUS_INVALID_PARAM;
	}

	jobject surfaceObj = env->CallObjectMethod(surfaceHolder, methodID);
	clazz = env->GetObjectClass(surfaceObj);
	if (NULL == clazz) {
		LOG_E(LOG_TAG, "Fail to get GetObjectClass of surfaceObj");
		return STATUS_INVALID_PARAM;
	}
	jfieldID fieldID = env->GetFieldID(clazz, "mNativeObject", "I");//mNativeSurface mSurface
	if (NULL == fieldID) {
		LOG_E(LOG_TAG, "Fail to GetFieldID of mSurface");
		return STATUS_INVALID_PARAM;
	}

	LOG_D(LOG_TAG, "Remote surfaceObj=%d,fieldID=%d", surfaceObj, fieldID);

	Surface * const p = (Surface*) env->GetIntField(surfaceObj, fieldID);
	if (NULL == p) {
		LOG_E(LOG_TAG, "Fail to GetIntField of surface");
		return STATUS_INVALID_PARAM;
	}

	Mutex::Autolock autoLock(mMediaLock);
	LOG_E(LOG_TAG, "setRemoteVideoSurface get the mMediaLock");
	int ret;
	HoriPhoneVideo* pVideo = pHoriPhoneVideoList[handle];
	if(pVideo != NULL)
	{
		ret = pVideo->setRemoteSurface(p);
	}
	else
	{
		LOG_E(LOG_TAG, "Video handle is not set, failed to set remote surface to handle %d", handle);
	}

	return ret;
}

//=========================================================================
// FunctionName: snapshot;
// Description : 触发抓拍;
// Input       : NA;
// Output      : NA;
// ReturnValue : 0: Fail; JNI_VERSION_1_6 Success;
// Other       : NA;
//=========================================================================

static int snapshot(JNIEnv *env, jobject thiz, int handle) {

	LOG_D(LOG_TAG, "Snapshot on handle %d.", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	
	int ret;
	HoriPhoneRecorder * pRecorder = new HoriPhoneRecorder();

	ret = pRecorder->init(pHoriPhoneVideoList[handle], pHoriPhoneAudioList[handle], 0);
	if(ret < 0)
	{
		LOG_E(LOG_TAG, "Init HoriPhoneRecorder failed.");
		return -1;
	}

	ret = pRecorder->snapshot();
		
	return ret;

}

static int getSnapData(JNIEnv *env, jobject thiz, int handle, jbyteArray out) {

	LOG_D(LOG_TAG, "getSnapData on handle %d", handle);
	/*if (handle < 0 || handle > MAX_PHONE_INSTANCE || NULL == instances[handle]) {
	 LOG_E(LOG_TAG, "Invalid parameters\n");
	 return STATUS_INVALID_PARAM;
	 }

	 jbyte * pixel = (jbyte*) env->GetByteArrayElements(out, 0);
	 int size = -1;
	 HoriPhone* phone = instances[handle];
	 phone->getSnapData((void **) &pixel, &size);


	 env->ReleaseByteArrayElements(out, pixel, 0);

	 return size;*/
	return 0;
}

//=========================================================================
// FunctionName: takeRecord;
// Description : 触发录像;
// Input       : NA;
// Output      : NA;
// ReturnValue : 0: Fail; JNI_VERSION_1_6 Success;
// Other       : NA;
//=========================================================================

static int toggleTakeRecord(JNIEnv *env, jobject thiz, int handle) {

	LOG_D(LOG_TAG, "toggleTakeRecord on handle %d.", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	if(pHoriPhoneRecorder != NULL)
	{
		delete pHoriPhoneRecorder;
		pHoriPhoneRecorder = NULL;
	}

	int ret;
	pHoriPhoneRecorder = new HoriPhoneRecorder();

	ret = pHoriPhoneRecorder->init(pHoriPhoneVideoList[handle], pHoriPhoneAudioList[handle], 1);
	if(ret < 0)
	{
		LOG_E(LOG_TAG, "Init HoriPhoneRecorder failed.");
		return -1;
	}

	ret = pHoriPhoneRecorder->toggleTakeRecord();

	return ret;
}

static int startTakeRecord(JNIEnv *env, jobject thiz, int handle, int recordSound, jstring jstr) {

	
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}

	/*
	 char * str;
	 str = (char*) env->GetStringUTFChars(s, NULL);
	 LOG_V(LOG_TAG, "recordname: %s", str);
	 env->ReleaseStringUTFChars(s, str);
	 */

	const char* str = env->GetStringUTFChars(jstr, JNI_FALSE);
	LOG_D(LOG_TAG, "startTakeRecord on handle %d, recordfilename=%s", handle, str);

	if(pHoriPhoneRecorder != NULL)
	{
		delete pHoriPhoneRecorder;
		pHoriPhoneRecorder = NULL;
	}

	int ret;
	pHoriPhoneRecorder = new HoriPhoneRecorder();

	ret = pHoriPhoneRecorder->init(pHoriPhoneVideoList[handle], pHoriPhoneAudioList[handle], recordSound);
	if(ret < 0)
	{
		LOG_E(LOG_TAG, "Init HoriPhoneRecorder failed.");
		return -1;
	}

	ret = pHoriPhoneRecorder->startTakeRecord(str);
	
	env->ReleaseStringUTFChars(jstr, str);
	return ret;
}

static int stopTakeRecord(JNIEnv *env, jobject thiz, int handle) {

	LOG_D(LOG_TAG, "stopTakeRecord on handle %d.", handle);
	if (handle < 0 || handle > MAX_PHONE_INSTANCE) {
		LOG_E(LOG_TAG, "Invalid parameters\n");
		return STATUS_INVALID_PARAM;
	}
	
	

	int ret;
	
	if(pHoriPhoneRecorder != NULL)
	{
		ret = pHoriPhoneRecorder->stopTakeRecord();

		pHoriPhoneRecorder->uninit();

		if(pHoriPhoneRecorder != NULL)
		{
			delete pHoriPhoneRecorder;
			pHoriPhoneRecorder = NULL;
		}
	}
	else
	{
		LOG_E(LOG_TAG, "No HoriPhoneRecorder object exist, has startTakeRecord been called?");
		return -1;
	}
	
	
	return ret;
}


static int setLogEnable(JNIEnv *env, jobject thiz, int isdolog)
{
	LOG_D(LOG_TAG, "setLogEnable: %d.", isdolog);

	setLogFlag(isdolog);

	return 1;

}

static int syncSystem(JNIEnv *env, jobject thiz)
{
	LOG_D(LOG_TAG, "Execute sync() for file system.");
	return system("sync");
}



/************JNI开始**********************/

//JNI method array
#ifdef VERSION_VPHONE
static JNINativeMethod gMethods[] = { 
			{"startChannel", "(Lcom/iss/videophone/codecengin/CodecParam;)I", (void*)startChannel },   //2014-7-1  Add by Jianghong
			{"stopChannel", "(I)I", (void*)stopChannel},
			{ "switchVideoOnOff", "(II)I", (void*) switchVideoOnOff }, 
			{ "switchAudioMute", "(II)I", (void*) switchAudioMute }, 
			{ "sendDTMF", "(II)I", (void*) sendDTMF }, 
			//{ "startRemotePreview", "(I)I", (void*) startRemotePreview }, 
			{ "snapshot", "(I)I", (void*) snapshot }, 
			{ "getSnapData", "(I[B)I",(void*) getSnapData }, 
			{ "toggleTakeRecord", "(I)I", (void*) toggleTakeRecord }, 
			{ "startTakeRecord", "(IILjava/lang/String;)I", (void*) startTakeRecord }, 
			{ "stopTakeRecord", "(I)I",(void*) stopTakeRecord },
			//{"stopPreview",             "()I",      (void*)stopPreview},
			{ "setCamera", "(II)I", (void*) setCamera },
			/*{ "setCamera", "(ILandroid/hardware/Camera;)I", (void*) setCamera },*/ 
			{ "setLocalVideoSurface","(ILandroid/view/SurfaceHolder;II)I", (void*) setLocalVideoSurface }, 
			{ "setRemoteVideoSurface", "(ILandroid/view/SurfaceHolder;II)I", (void*) setRemoteVideoSurface }, 
			{ "setObserver", "(ILcom/iss/videophone/codecengin/CodecEngin;)I", (void*) setObserver },
			{"setLogFlag", "(I)I", (void*)setLogEnable},
			{"syncSystem", "()I", (void*)syncSystem},
    		//{"setPreviewSurface",       "(Landroid/view/SurfaceHolder;II)I",   (void*)setPreviewSurface},
	  };

#endif

#ifdef VERSION_VDOOR
static JNINativeMethod gMethods[] = { 
			{"startChannel", "(Lcom/iss/vdoor/codecengin/CodecParam;)I", (void*)startChannel },   //2014-7-1  Add by Jianghong
			{"stopChannel", "(I)I", (void*)stopChannel},
			{ "switchVideoOnOff", "(II)I", (void*) switchVideoOnOff }, 
			{ "switchAudioMute", "(II)I", (void*) switchAudioMute }, 
			{ "sendDTMF", "(II)I", (void*) sendDTMF }, 
			//{ "startRemotePreview", "(I)I", (void*) startRemotePreview }, 
			{ "snapshot", "(I)I", (void*) snapshot }, 
			{ "getSnapData", "(I[B)I",(void*) getSnapData }, 
			{ "toggleTakeRecord", "(I)I", (void*) toggleTakeRecord }, 
			{ "startTakeRecord", "(IILjava/lang/String;)I", (void*) startTakeRecord }, 
			{ "stopTakeRecord", "(I)I",(void*) stopTakeRecord },
			//{"stopPreview",             "()I",      (void*)stopPreview},
			{ "setCamera", "(II)I", (void*) setCamera },
			/*{ "setCamera", "(ILandroid/hardware/Camera;)I", (void*) setCamera },*/ 
			{ "setLocalVideoSurface","(ILandroid/view/SurfaceHolder;II)I", (void*) setLocalVideoSurface }, 
			{ "setRemoteVideoSurface", "(ILandroid/view/SurfaceHolder;II)I", (void*) setRemoteVideoSurface }, 
			{ "setObserver", "(ILcom/iss/vdoor/codecengin/CodecEngin;)I", (void*) setObserver },
			{"setLogFlag", "(I)I", (void*)setLogEnable},
			{"syncSystem", "()I", (void*)syncSystem},
    		//{"setPreviewSurface",       "(Landroid/view/SurfaceHolder;II)I",   (void*)setPreviewSurface},
	  };

#endif




//=========================================================================
// FunctionName: register_SIPPhone;
// Description : Register SIPPhone native methods to AndroidRuntime;
// Input       : NA;
// Output      : NA;
// ReturnValue : 0: Success; -1: Fail;
// Other       : NA;
//=========================================================================

static int register_horitalk(JNIEnv *env) {

	#ifdef VERSION_VPHONE
	int ret = AndroidRuntime::registerNativeMethods(env, "com/iss/videophone/codecengin/CodecEngin", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	#endif

	#ifdef VERSION_VDOOR
	int ret = AndroidRuntime::registerNativeMethods(env, "com/iss/vdoor/codecengin/CodecEngin", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	#endif
	
	return ret;
}

//=========================================================================
// FunctionName: JNI_OnLoad;
// Description : Init global variables and register native methods;
// Input       : NA;
// Output      : NA;
// ReturnValue : -1: Fail; JNI_VERSION_1_6 Success;
// Other       : NA;
//=========================================================================

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	JNIEnv* env = NULL;
	jint result = -1;

	if (vm->GetEnv((void**) &env, JNI_VERSION_1_6) != JNI_OK) {
		LOG_E(LOG_TAG, "ERROR: GetEnv failed\n");
		return result;
	}

	if (NULL == env) {
		LOG_E(LOG_TAG, "NULL env");
		return result;
	}

	if (0 != register_horitalk(env)) {
		LOG_E(LOG_TAG, "Fail to register_horitalk");
		return result;
	}

	//Success Here
	result = JNI_VERSION_1_6;
	return result;
}




/************JNI方法结束**********************/
