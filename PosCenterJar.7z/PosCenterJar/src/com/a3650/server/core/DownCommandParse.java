package com.a3650.server.core;

import java.io.UnsupportedEncodingException;

import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.common.TypeConversion;

/**
 * 构造下行命令体
 * 
 * @author Administrator
 * 
 */
public class DownCommandParse {

	private DownCommandBean downCommandBean;//命令内容对象

	/**
	 * 构造函数
	 * @roseuid 4DF8330C01E4
	 */
	public DownCommandParse(DownCommandBean downCommandBean){
		this.downCommandBean = downCommandBean;
	}

	/**
	 * 把下发命令对象解析成BYTE数组，其中包含命令头和命令体
	 * 命令头长度为56字节
	 * @return byte[]
	 * @roseuid 4DF7142D0261
	 */
	public byte[] getCommandBuffer(CryptionControl cryptionControl)  throws CommandParseException{
		if(downCommandBean==null){
			throw new CommandParseException("返回对象为空"); 
		}
		byte[] sendByte = null;
		try{
			byte[] body = null;
			byte[] temp = downCommandBean.parseBody();//获取命令体的字节码
			int oldBodyLength = temp.length;
			if(oldBodyLength%8>0){//如果命令体长度不是8的倍数
				body = new byte[oldBodyLength+8-oldBodyLength%8];
				System.arraycopy(temp, 0, body, 0, oldBodyLength);
			}else{
				body = temp;
			}
			//对命令体进行加密并计算消息摘要
			body = cryptionControl.getDES(downCommandBean.getCommandBean().getCommandCode(),body);//加密
			byte[] mac = cryptionControl.getMAC(downCommandBean.getCommandBean().getCommandCode(),body);//计算摘要
			
			/*
			 * 命令头格式(请参照协议)
			 */
			sendByte = new byte[69+body.length];
			System.arraycopy(TypeConversion.shortToBytes((short)(sendByte.length-2)), 0, sendByte, 0, 2);//	命令长度	Len	HEX	2	表示命令的整体长度，但是不包含本身这2个字节； 
			System.arraycopy(TypeConversion.stringToAscii(downCommandBean.getCommandBean().getCommandCode()), 0, sendByte, 2, 6);//命令码	CommandCode	ASC 	6	具体的命令，应与上行命令相同
			System.arraycopy(TypeConversion.intToBytes(downCommandBean.getCommandBean().getComSeq()), 0, sendByte, 8, 4);//命令序列	ComSeq	HEX	4	表示该命令的应答序列号，应与上行命令相同
			System.arraycopy(mac, 0, sendByte, 12, 8);//数字签名	MAC	HEX	16	经过加密计算得到8个字节数字签名，填充前8字节，后8字节预留暂不使用
			sendByte[28]=downCommandBean.getAnswerCode();//应答码	AnswerCode	HEX	1
			if(downCommandBean.getAnswerMsg()!=null){
				//应答信息	AnswerMsg	ASC	20	表示后台给服务器的应答信息。如果不足字节后面的用0x00补充。（应答码为0x00时本域无效）
				byte[] answerMsg = TypeConversion.stringToAscii(downCommandBean.getAnswerMsg());
				System.arraycopy(answerMsg, 0, sendByte, 29, answerMsg.length>20?20:answerMsg.length);
			}
			/**
			if(downCommandBean.getCommandBean().getMark()!=null){
				//应答信息	Mark	ASC	20	和上一字段一起构成应答信息
				byte[] answerMsg = TypeConversion.stringToAscii(downCommandBean.getCommandBean().getMark());
				System.arraycopy(answerMsg, 0, sendByte, 49, answerMsg.length>20?20:answerMsg.length);
			}
			*/
			//加密后的命令体
			System.arraycopy(body, 0, sendByte, 69, body.length);
			return sendByte;
		}catch(Exception ue){
			throw new CommandParseException("构造返回数据异常"); 
		}
	}

}
