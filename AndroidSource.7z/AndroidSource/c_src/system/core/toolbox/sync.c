#include <unistd.h>

int sync_main(int argc, char **argv)
{
	sync();
	return 0;
}
