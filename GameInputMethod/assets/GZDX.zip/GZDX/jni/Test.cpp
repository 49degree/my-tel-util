#include <string.h>
#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <gui/Surface.h>
#include <camera/Camera.h>
#include <camera/ICamera.h>
#include <camera/CameraParameters.h>

#include <media/stagefright/CameraSource.h>
#include <media/stagefright/CameraSourceTimeLapse.h>

#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/MetaData.h>
#include <media/stagefright/OMXClient.h>
#include <media/stagefright/OMXCodec.h>

#include <media/IMediaRecorderClient.h>
#include <media/MediaProfiles.h>

#include <android_runtime/AndroidRuntime.h>
#include <android/log.h>

#include <utils/Errors.h>
#include <sys/types.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>

#include <sys/prctl.h>
#include <sys/stat.h>

#include <arpa/inet.h>
#include <sys/socket.h>
#include <stdio.h>

#include <media/stagefright/foundation/ADebug.h>

#include "VideoRecorder.h";


#define LOGTAG "Test"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOGTAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOGTAG,__VA_ARGS__)


using namespace android;

sp<Surface> mPreviewSurface;
static sp<VideoRecorder> mVideoRecorder;
static int mVideoSocket = -1;


int MakeUDPSocket(unsigned port) {
	int s = socket(AF_INET, SOCK_DGRAM, 0);
	CHECK_GE(s, 0);

	struct sockaddr_in addr;
	memset(addr.sin_zero, 0, sizeof(addr.sin_zero));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(port);

	if(0 > bind(s, (const struct sockaddr *) &addr, sizeof(addr)))
	{
		LOGE(LOG_TAG,"Bind socket to port %d for video fail, err=%d.", port, errno);
		return -1;
	}
	return s;
}

int Prepare()
{

	return 1;
}

int start()
{
	int mVideoSocket = MakeUDPSocket(5008);
	mVideoRecorder = new VideoRecorder();
	mVideoRecorder->setParamVideoCameraId(0);//camera
	mVideoRecorder->setParamVideoEncodingBitRate(960000);
	mVideoRecorder->setParamVideoIFramesInterval(1);
	mVideoRecorder->setVideoFrameRate(25);
	mVideoRecorder->setVideoSize(640, 480);
	mVideoRecorder->setupConn(mVideoSocket,"172.0.0.133",5006, 0);
	mVideoRecorder->setPreviewSurface(mPreviewSurface); //->getISurface()


	//mVideoRecorder->start();

	return 1;
}

static jint startRtp(JNIEnv *env, jobject thiz,jobject surfaceHolder)
{
	LOGD( "Execute sync() for file system.");
	//Get Surface object of SurfaceHolder
	jclass clazz = env->GetObjectClass(surfaceHolder);
	jmethodID methodID = env->GetMethodID(clazz, "getSurface", "()Landroid/view/Surface;");
	if (NULL == methodID) {
		LOGE("Fail to call GetMethodID getSurface");
		return 0;
	}

	jobject surfaceObj = env->CallObjectMethod(surfaceHolder, methodID);
	clazz = env->GetObjectClass(surfaceObj);
	if (NULL == clazz) {
		LOGE("Fail to get GetObjectClass of surfaceObj");
		return 0;
	}
	jfieldID fieldID = env->GetFieldID(clazz, "mNativeObject", "I");//mNativeSurface
	if (NULL == fieldID) {
		LOGE("Fail to GetFieldID of mSurface");
		return 0;
	}

	//LOGE("Local surfaceObj=%d,fieldID=%d", surfaceObj, fieldID);

	mPreviewSurface = (Surface*) env->GetIntField(surfaceObj, fieldID);
	//LOGE("mPreviewSurface============ %d",&mPreviewSurface);
	if (mPreviewSurface==0) {
		LOGE("Fail to GetIntField of surface");
		return 0;
	}

	start();

	return OK;
}

static jint stopSystem(JNIEnv *env, jobject thiz)
{
	LOGE("stopSystem===========");

	if(mVideoRecorder!=NULL)
		mVideoRecorder->stop();
	close(mVideoSocket);
	mVideoSocket = -1;

	return OK;
}
static JNINativeMethod gMethods[] = { 
			{"syncSystem", "(Landroid/view/SurfaceHolder;)I", (void*)startRtp},
			{"stopSystem", "()I", (void*)stopSystem}
	  };




//=========================================================================
// FunctionName: register_SIPPhone;
// Description : Register SIPPhone native methods to AndroidRuntime;
// Input       : NA;
// Output      : NA;
// ReturnValue : 0: Success; -1: Fail;
// Other       : NA;
//=========================================================================

/*
 * Register native JNI-callable methods.
 * "className" looks like "java/lang/String".
 */
int jniRegisterNativeMethods(JNIEnv* env, const char* className, const JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;
    LOGE("jniRegisterNativeMethods===================");
    clazz = env->FindClass(className);
    if (clazz == NULL)
        return -1;
    LOGE("%s",className);
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0)
        return -1;

    return 0;
}

static int register_horitalk(JNIEnv *env) {
	LOGE("register_horitalk===================");
	int ret = AndroidRuntime::registerNativeMethods(env, "com/example/gzdx/Test", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	//int ret = jniRegisterNativeMethods(env, "com/example/gzdx/Test", gMethods, sizeof(gMethods) / sizeof(gMethods[0]));
	return ret;
}

//=========================================================================
// FunctionName: JNI_OnLoad;
// Description : Init global variables and register native methods;
// Input       : NA;
// Output      : NA;
// ReturnValue : -1: Fail; JNI_VERSION_1_6 Success;
// Other       : NA;
//=========================================================================

jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	JNIEnv* env = NULL;
	jint result = -1;
	LOGE("JNI_OnLoad===================");
	if (vm->GetEnv((void**) &env, JNI_VERSION_1_6) != JNI_OK) {
		LOGE("ERROR: GetEnv failed\n");
		return result;
	}

	if (NULL == env) {
		LOGE( "NULL env");
		return result;
	}

	if (0 != register_horitalk(env)) {
		LOGE("Fail to register_horitalk");
		return result;
	}

	//Success Here
	result = JNI_VERSION_1_6;
	return result;
}

