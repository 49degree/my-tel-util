package com.iss.vdoor.codecengin;


import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.os.Build;
import android.view.SurfaceHolder;


public class CodecController {
	
private static String TAG = "CodecController";
	
	private static CodecController coderController;
	
	
	public static CodecController getInstance(){
		
		if(coderController == null){
			coderController = new CodecController();   
		}
		
		return coderController;
	}
	
	
	
	public void codecStartPrepare(int handle, CodecParam param){
		
		Logger.debug(TAG, "Now start codec channel ."+handle);
		
		CodecEngin codec = CodecEngin.getInstance();
		codec.startChannel(param);
		
		//鎸囩ず闊宠棰戝惎鍔ㄥ畬鎴愶紝浠ユ槸鐨剆etLocalview鍜宻etRemoteView鑳藉琚鐞�
		//CallManager.getInstance().SetHasCodecBegin(handle, true);
	}
	
	
	public void setLocalview(int handle, SurfaceHolder mLocalSurface){
		CodecEngin codec = CodecEngin.getInstance();
		
		Logger.debug(TAG, "Camera.getNumberOfCameras() = " + Camera.getNumberOfCameras());
		if (Camera.getNumberOfCameras() >= 1) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
				for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
					CameraInfo info = new CameraInfo();
					Camera.getCameraInfo(i, info);
					Logger.debug(TAG, "info.facing = "+info.facing);
					if (1 == Camera.getNumberOfCameras() || info.facing == CameraInfo.CAMERA_FACING_FRONT) {//杩欏氨鏄墠缃憚鍍忓ご锛屼翰銆�
						
						//绛夊緟闊宠棰戝鐞嗗惎鍔�
						//CallManager.getInstance().WaitForCodecBeing(handle);
						
						codec.setCamera(handle, i);
						codec.setLocalVideoSurface(handle, mLocalSurface, 352, 288);
						Logger.debug(TAG, "Set local view object for handle "+handle+" succeed.");
					}
				}
			}
		}
	}
	
	public void setRemoteView(int handle, SurfaceHolder mRemoteSurface){
		
		CodecEngin codec = CodecEngin.getInstance();
		
		
		//绛夊緟闊宠棰戝鐞嗗惎鍔�
		//CallManager.getInstance().WaitForCodecBeing(handle);
		
		codec.setRemoteVideoSurface(handle, mRemoteSurface, 704, 576);
		
		Logger.debug(TAG, "Set remote view object for handle "+handle+" succeed.");
	}
	
	
	public void codecStop(int handle){
		
		Logger.debug(TAG, "Now stop codec on handle "+handle);
		
		CodecEngin codec = CodecEngin.getInstance();
		
		codec.stopChannel(handle);
	
	}
	
	
	
	
	public void handleMessage(String[] keys, String[] values){
		
		
		if(false == keys[0].equals("host")){
			return;
		}
		
		String msg = getValueByKey(keys, values, "msg");
		
		if(msg == null) return;
		
		
		
		if("open".equals(msg)){
			
			String tmp;
			
			CodecParam param = new CodecParam();
			
			
			//瑙ｉ噴鑾峰彇鍏叡鍙傛暟
			if((tmp = getValueByKey(keys, values, "channel")) != null){
				param.handle = Integer.parseInt(tmp);
			}
			
			param.localIP = "191.8.1.96";
			
			
			
			//瑙ｉ噴鑾峰彇闊抽鍙傛暟
			if((tmp = getValueByKey(keys, values, "audioremoteip")) != null){
				param.remoteAudioIP = tmp;
			}
			
			if((tmp = getValueByKey(keys, values, "audiolocalport")) != null){
				param.localAudioPort = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "audioremoteport")) != null){
				param.remoteAudioPort = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "audiopayload")) != null){
				
				param.audioPayloadName = tmp;
				
				if(tmp.equals("G.711a")){
					param.audioPayloadID = param.PT_G711A;
				}else if(tmp.equals("G.711u")){
					param.audioPayloadID = param.PT_G711U;
				}else if(tmp.equals("G.729")){
					param.audioPayloadID = param.PT_G729;
				}
				
			}
			
			if((tmp = getValueByKey(keys, values, "audiopayload_value")) != null){
				
				param.audioPayloadID = Integer.parseInt(tmp);
		
			}
		 
	
			if((tmp = getValueByKey(keys, values, "telephone_event")) != null){
				int b = Integer.parseInt(tmp);
				if(101 == b){
					param.dtmfBand = 0;
				}else if(0 == b){
					param.dtmfBand = 1;
				}
				
			}
			
			if((tmp = getValueByKey(keys, values, "telephone_event_payload")) != null){
				int b = Integer.parseInt(tmp);
				param.dtmfPayloadID = b;
				
			}
			
			if((tmp = getValueByKey(keys, values, "audiodirection")) != null){
				if("sendrecv".equals(tmp)){
					param.audioDirect = param.DIRECT_SENDRECV;
				}else if("inactive".equals(tmp)){
					param.audioDirect = param.DIRECT_INACTIVE;
				}else if("sendonly".equals(tmp)){
					param.audioDirect = param.DIRECT_SENDONLY;
				}else if("recvonly".equals(tmp)){
					param.audioDirect = param.DIRECT_RECVONLY;
				}
			}
			
			
			//瑙ｉ噴鑾峰彇瑙嗛鍙傛暟
			if((tmp = getValueByKey(keys, values, "videoremoteip")) != null){
				param.remoteVideoIP = tmp;
			}
			
			if((tmp = getValueByKey(keys, values, "videolocalport")) != null){
				param.localVideoPort = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videoremoteport")) != null){
				param.remoteVideoPort = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videopayload")) != null){
				param.videoPayloadName = tmp;
			}
			
			if((tmp = getValueByKey(keys, values, "videopayloadID")) != null){
				param.videoPayloadID = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videoformat")) != null){
				if("cif".equals(tmp)){
					param.resolution = param.VIDEO_RESL_CIF;
				}else if("4cif".equals(tmp)){
					param.resolution = param.VIDEO_RESL_4CIF;
				}else if("qcif".equals(tmp)){
					param.resolution = param.VIDEO_RESL_QCIF;
				}
		
			}
			
			if((tmp = getValueByKey(keys, values, "videostream")) != null){
				param.bitRate = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videowidth")) != null){
				param.videoWidth = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videoheight")) != null){
				param.videoHeight = Integer.parseInt(tmp);
			}
						
			if((tmp = getValueByKey(keys, values, "frameRate")) != null){
				param.frameRate = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "H264_level_id")) != null){
				param.H264Level = Integer.parseInt(tmp);
			}
			
			if((tmp = getValueByKey(keys, values, "videodirection")) != null){
				if("sendrecv".equals(tmp)){
					param.videoDirect = param.DIRECT_SENDRECV;
				}else if("inactive".equals(tmp)){
					param.videoDirect = param.DIRECT_INACTIVE;
				}else if("sendonly".equals(tmp)){
					param.videoDirect = param.DIRECT_SENDONLY;
				}else if("recvonly".equals(tmp)){
					param.videoDirect = param.DIRECT_RECVONLY;
				}
			}
				
			//param.mode = CallManager.getInstance().getMediaModeofCallObj(param.handle);
			
			Logger.debug(TAG, "Codec Engin param:");
			Logger.debug(TAG, "handle: "+ param.handle);
			Logger.debug(TAG, "localIP: "+ param.localIP);
			
			Logger.debug(TAG, "remoteAudioIP: "+ param.remoteAudioIP);
			Logger.debug(TAG, "localAudioPort: "+param.localAudioPort);
			Logger.debug(TAG, "remoteAudioPort: "+ param.remoteAudioPort);
			Logger.debug(TAG, "audioPayloadName: "+ param.audioPayloadName);
			Logger.debug(TAG, "audioPayloadID: "+ param.audioPayloadID);	
			Logger.debug(TAG, "dtmfBand: "+param.dtmfBand);
			Logger.debug(TAG, "dtmfPayloadID: "+param.dtmfPayloadID);
			Logger.debug(TAG, "audioDirect: "+param.audioDirect);
			
			Logger.debug(TAG, "remoteVideoIP: "+param.remoteVideoIP);
			Logger.debug(TAG, "remoteVideoPort: "+param.remoteVideoPort);
			Logger.debug(TAG, "localVideoPort: "+param.localVideoPort);
		    Logger.debug(TAG, "videoPayloadName: "+param.videoPayloadName);
		    Logger.debug(TAG, "videoPayloadID: "+param.videoPayloadID);
		    Logger.debug(TAG, "bitRate: "+param.bitRate);
		    Logger.debug(TAG, "mode="+param.mode);
			Logger.debug(TAG, "resolution: "+param.resolution);
			Logger.debug(TAG, "videoWidth: "+param.videoWidth);
			Logger.debug(TAG, "videoHeight: "+param.videoHeight);
			Logger.debug(TAG, "frameRate: "+param.frameRate);
			Logger.debug(TAG, "H264Level: "+param.H264Level);
			Logger.debug(TAG, "videoDirect: "+param.videoDirect);
			
			
			codecStartPrepare(param.handle, param); 
			
			
			
			
		}else if("close".equals(msg)){
			
			String tmp;
			int handle  = -1;
			
			if((tmp = getValueByKey(keys, values, "channel")) != null){
				handle = Integer.parseInt(tmp);
			}
			
			codecStop(handle);
		}
		
		
	}
	
	
	
	private String getValueByKey(String[] keys, String[] values, String keyName){
		
		for(int i=0; i< keys.length; i++){
			if(keyName.equals(keys[i])){
				return values[i];
			}
		}
		
		
		return null;
		
	}
	


}
