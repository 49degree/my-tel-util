package com.a3650.server.bean;

public class CommandBean {
	// 命令码
	private String commandCode;
	// 终端ID
	private String posID;
	// 命令序列
	private int comSeq;


	public String getCommandCode() {
		return commandCode;
	}
	public void setCommandCode(String commandCode) {
		this.commandCode = commandCode;
	}
	public String getPosID() {
		return posID;
	}
	public void setPosID(String posID) {
		this.posID = posID;
	}

	public int getComSeq() {
		return comSeq;
	}
	public void setComSeq(int comSeq) {
		this.comSeq = comSeq;
	}

	
	
	
}
