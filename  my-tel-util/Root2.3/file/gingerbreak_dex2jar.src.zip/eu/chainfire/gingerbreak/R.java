package eu.chainfire.gingerbreak;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int icon = 2130837504;
  }

  public static final class string
  {
    public static final int app_name = 2130903040;
  }
}

/* Location:           E:\开发工具\android开发工具\反编译工具\apktool2.2\gingerbreak\gingerbreak_dex2jar.jar
 * Qualified Name:     eu.chainfire.gingerbreak.R
 * JD-Core Version:    0.6.0
 */