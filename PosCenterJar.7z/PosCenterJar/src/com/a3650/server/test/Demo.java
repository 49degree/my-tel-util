package com.a3650.server.test;

import com.a3650.server.bean.CommandBean;
import com.a3650.server.bean.DownCommandBean;
import com.a3650.server.bean.UpCommandBean;
import com.a3650.server.bean.impl.DownLoginBean;
import com.a3650.server.bean.impl.DownSaleBillBean;
import com.a3650.server.bean.impl.UpLoginBean;
import com.a3650.server.bean.impl.UpSaleBillBean;
import com.a3650.server.core.CommandControl;

public class Demo {
	public static void main(String[] args){
		//接收POS上传数据（长度（2B不包括长度的2B）+命令体）
		byte[] receiveBuffer = receiveMsg();//(receiveBuffer包含数据长度2byte)

		//调用A3650PosCenter.jar中的方法解析数据得到对象
		UpCommandBean upCommandBean = 
			CommandControl.parseUpComand(receiveBuffer);
		//判断接收的数据是否需要业务处理
		if(upCommandBean.getParseErrorCode()!=0){
			//不需要业务处理，则直接返回JAR包中已经构造的数据给POS
			sendMsg(upCommandBean.getErrorReturnBuffer());
			return ;
		}
		
		//返回POS数据对象
		DownCommandBean downCommandBean = null;
		//处理业务逻辑（根据命令ID区分不同的业务）
		CommandBean commandBean = upCommandBean.getCommandBean();
		if(upCommandBean instanceof UpLoginBean){//登录
			UpLoginBean realBean = (UpLoginBean)upCommandBean;//转换成实际类型
			
			//构造返回对象
			DownLoginBean downLoginBean = new DownLoginBean();
			downLoginBean.setCommandBean(commandBean);
			/*******************************************************************
			 * 以下进行登录业务逻辑处理，登录所需要数据均在UpLoginBean对象中
			 * 处理把需要返回POS的数据放入DownLoginBean对象中
		     *******************************************************************/
			
			downCommandBean = downLoginBean;
			
	    }else if(upCommandBean instanceof UpSaleBillBean){//售单
	    	UpSaleBillBean realBean = 
	    		(UpSaleBillBean)upCommandBean;//转换成实际类型
	    	//以下进行售单业务逻辑处理，售单所需要数据均在UpSaleBillBean对象中
			//构造返回对象
	    	DownSaleBillBean downSaleBillBean = new DownSaleBillBean();
	    	downSaleBillBean.setCommandBean(commandBean);
			/*******************************************************************
			 * 以下进行登录业务逻辑处理，登录所需要数据均在UpLoginBean对象中
			 * 处理把需要返回POS的数据放入DownLoginBean对象中
		     *******************************************************************/
			downCommandBean = downSaleBillBean;   	
	    	
	    }
		//解析返回POS的对象为字节流
		byte[] sendBuffer = 
			CommandControl.parseDownComand(downCommandBean);
		
		//以下2参数告诉保险公司系统构造解析是否成功，
		//可不用处理直接返回数据sendBuffer
		downCommandBean.getCreateErrorCode();//解析数据结果0=成功，其他失败
		downCommandBean.getCreateErrorMsg();//构造返回失败说明
		//发送数据到POS终端
		sendMsg(sendBuffer);
		
		
		
	}
	
	/**
	 * 接收POS数据
	 * @return
	 */
	public static byte[] receiveMsg(){
		return null;
	}
	/**
	 * 返回数据给POS
	 * @return
	 */
	public static void sendMsg(byte[] buffer){
	
	}
}
