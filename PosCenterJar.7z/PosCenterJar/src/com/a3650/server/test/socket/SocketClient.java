/***********************************************************************
 * Module:  SocketClient.java
 * Author:  Administrator
 * Purpose: Defines the Class SocketClient
 ***********************************************************************/

package com.a3650.server.test.socket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import com.a3650.server.common.TypeConversion;




public class SocketClient{
	public final static int READ_TIMEOUT = 10000; //读取超时时间(10S)
	private InputStream in = null;
	private OutputStream out = null;
	private byte[] recvAllBuffer = new byte[2048];//接收到的数据缓冲区
	//private byte[] recvbuf = new byte[512];// 1KB的缓冲区
	private int recvAllBufferIndex = 0;
	
	private boolean stopReceive = false;
	private Socket mClient = null;

	public SocketClient(Socket client) throws IOException{
		mClient = client;
		try{
			mClient.setSoTimeout(READ_TIMEOUT);
			mClient.setTcpNoDelay(true);
			in = mClient.getInputStream();
			out = mClient.getOutputStream();
			System.out.println("客户端连接成功.........");
		}catch(IOException e){
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * 接收数据
	 */
	
	public byte[] receiveData() throws IOException{
		try {
			//logger.debug("开始接收数据！！！！！！！！！！！");
			// TODO Auto-generated method stub
			int bufferLength = 0;
			while (in != null && !stopReceive) {
				
				recvAllBuffer[0] = (byte)in.read();
				recvAllBuffer[1] = (byte)in.read();
				recvAllBufferIndex = 2;
				
				bufferLength = TypeConversion.bytesToShort(recvAllBuffer, 0);
				System.out.println("数据长度："+bufferLength);
				
				if (bufferLength<1) {
					stopReceive = true;
					break;
				}
				
				System.out.println("可获取数据："+in.available());
				
				
				int nReadbyteLength = in.read(recvAllBuffer,2,bufferLength);// 读取数据
				if (nReadbyteLength > 0) {
					recvAllBufferIndex += nReadbyteLength;
					//logger.debug("收到数据："+TypeConversion.byte2hex(recvAllBuffer,0,recvAllBufferIndex));
					//判断收到数据是否已经收完
					if (bufferLength <= recvAllBufferIndex - 2) {
						stopReceive = true;
					}
				} else {
					stopReceive = true;
				}
			}
			// 解析接收到的数据
			if (recvAllBufferIndex > 0) {
				byte[] returnData = new byte[recvAllBufferIndex];
				System.arraycopy(recvAllBuffer, 0, returnData, 0,recvAllBufferIndex);
				return returnData;
			}
		} catch (IOException e) {
			throw e;
		}finally{
			recvAllBufferIndex = 0;
		}
		return null;
	}

	
	/**
	 * 返回数据
	 */
	
	public boolean returnData(byte[] buffer)  throws IOException{
		// TODO Auto-generated method stub
		try {
			out.write(buffer);
			out.flush();
			return true;
		} catch (IOException e) {
			throw e;
		}finally{
		}
	}
	
	
	/**
	 *  关闭服务器连接
	 *  connectTimeOut;//连接超时时间
	 *  readTimeOut;//数据发送超时时间
	 */
	public synchronized boolean close(){
		// 关闭连接
		try {
			in.close();
			in = null;
			out.close();
			out = null;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		try {
			mClient.close();
			mClient = null;
		} catch (Exception ex) {
		}
		if(closeListener!=null){
			closeListener.close();
		}
		return true;
	}	
	
	
	/**
	 * 用于把一个byte数组复制到另一个数组
	 * @param source 被填充的目的数组
	 * @param index  填充的开始位置
	 * @param newSource 将要填充的数据
	 * @param begin     开始取数据的位置 
	 * @param length    取数据长度
	 * @param addLength 当被填充数组不够大时额外增加的长度
	 * @return
	 */
	public static byte[] insertEnoughLengthBuffer(byte[] source,int index,byte[] newSource,int begin,int length,int addLength){
		//判断长度是否足够
		if(source.length<index+length){
			byte[] temp = new byte[index+length+addLength];
			System.arraycopy(source, 0, temp, 0, source.length);
			source = temp;
		}
		System.arraycopy(newSource, begin, source, index, length);
		return source;
	}
	
	
	public CloseListener closeListener = null;
	
	public CloseListener getCloseListener() {
		return closeListener;
	}

	public void setCloseListener(CloseListener closeListener) {
		this.closeListener = closeListener;
	}

	public interface CloseListener{
		public void close();
	}
	

}