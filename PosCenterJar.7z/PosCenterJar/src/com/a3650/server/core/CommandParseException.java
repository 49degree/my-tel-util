package com.a3650.server.core;

public class CommandParseException extends Exception{
	public CommandParseException(String message){
		super(message);
	}
}
