#include <EGL/egl.h>
#include <GLES/gl.h>

#include <androidfw/AssetManager.h>
#include <utils/Errors.h>

#include <media/stagefright/foundation/ABase.h>
#include <media/stagefright/foundation/AHandlerReflector.h>
#include <media/stagefright/foundation/AString.h>
#include <media/stagefright/foundation/base64.h>

#include <media/stagefright/MediaBuffer.h>
#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/MediaSource.h>
#include <media/stagefright/MetaData.h>

#include <SoftwareRenderer.h>

namespace android {

class Surface;
class SurfaceComposerClient;
class SurfaceControl;

struct MediaBuffer;

struct HardView:public IBinder::DeathRecipient{
	HardView(int w,int h,sp<MetaData> meta);
	virtual ~HardView();
	status_t setImage(MediaBuffer* mediaBuffer);
	 sp<SurfaceComposerClient> session() const;
	status_t initWindow();
	virtual void            onFirstRef();
	virtual bool android();
	virtual void checkExit();
private:
    struct Texture {
        GLint   w;
        GLint   h;
        GLuint  name;
    };

	sp<SurfaceComposerClient>       mSession;
    sp<SurfaceControl> mFlingerSurfaceControl;
    sp<Surface> mFlingerSurface;

    sp<MetaData> mMeta;
    SoftwareRenderer *mTarget;

    EGLDisplay  mDisplay;
    EGLDisplay  mContext;
    EGLDisplay  mSurface;

    int         mWidth;
    int         mHeight;

    int videoW;
    int videoH;

    bool stop = false;
    bool exitFlag = false;

    AssetManager mAssets;
    Texture     mAndroid[2];
    nsecs_t startTime;



protected:

    virtual status_t initTexture(Texture* texture, AssetManager& assets,const char* name);
    virtual status_t initTexture(void* buffer, size_t len,int width,int height);

	virtual void binderDied(const wp<IBinder>& who);
};

}
