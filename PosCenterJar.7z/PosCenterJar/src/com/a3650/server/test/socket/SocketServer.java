/***********************************************************************
 * Module:  SocketServer.java
 * Author:  Administrator
 * Purpose: Defines the Class SocketServer
 ***********************************************************************/

package com.a3650.server.test.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.a3650.server.test.socket.SocketClient.CloseListener;

public class SocketServer implements Runnable {
	public final static int SERVER_PORT = 2666; //端口号
	private ServerSocket serverSocket = null;

	private Boolean serverStop = new Boolean(false);
	private ExecutorService clientThreadPool = null;//线程池
	private ClientCount clientCount = new ClientCount();
	
	public SocketServer(){
		clientThreadPool = Executors.newFixedThreadPool(50);
	}

	public int startBusiness(OperatorCenter operatorCenter) {
		// TODO Auto-generated method stub
		clientThreadPool.execute(operatorCenter);
		return 0;
	}
	/**
	 * 启动服务
	 */
	public void run() {
		try {
			System.out.println("服务器启动中...........");
			serverSocket = new ServerSocket();
			serverSocket.bind(new InetSocketAddress(SERVER_PORT)); // 绑定端口
			System.out.println("服务器启动成功，等待接入...........");
			while(!serverStop.booleanValue()){
				Socket client = serverSocket.accept();
				accept(client);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

	}
	
	/**
	 *停止服务 
	 */
	public void stopServer(){
		try{
			Thread.currentThread().interrupt();
			serverStop = new Boolean(true);
		}catch(Exception e){}
	}
	
	
	/**
	 * 接收连接
	 * @param key
	 * @throws IOException
	 */
	private void accept(final Socket client) {
		try {
			synchronized (clientCount) {
				clientCount.count = clientCount.count+1;
				System.out.println("客户端接入,当前客户总数："+clientCount.count);
			}
			
			SocketClient socketClient = new SocketClient(client);
			//客户端关闭回调对象
			socketClient.setCloseListener(new CloseListener(){
				public void close(){//客户端关闭回调方法
					synchronized (clientCount) {
						clientCount.count = clientCount.count-1;
						System.out.println("客户端关闭,当前客户总数："+clientCount.count);
					}
				}
			});
			
			startBusiness(new OperatorCenter(socketClient));
		} catch (Exception re) {
			//logger.error("处理连接失败");
			re.printStackTrace();
		}
	}
    
	private class ClientCount{
		int count = 0 ;
	}
	
	/**
	 * 类级的内部类，也就是静态的成员式内部类，该内部类的实例与外部类的实例没有绑定关系， 而且只有被调用到才会装载，从而实现了延迟加载
	 **/
	public static class Context {
		/**
		 * 静态初始化器，由JVM来保证线程安全
		 */
		public static SocketServer context = new SocketServer();

		public static void start() {
			new Thread(context).start();
		}
	}
	

}