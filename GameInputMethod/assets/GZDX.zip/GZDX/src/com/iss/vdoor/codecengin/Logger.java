package com.iss.vdoor.codecengin;

public class Logger {
	public static void debug(String tag,String msg){
		
	}
}
