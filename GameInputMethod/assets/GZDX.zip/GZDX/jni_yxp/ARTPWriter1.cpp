/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//#define LOG_NDEBUG 0
#define LOG_TAG "ARTPWriter1"
#include <utils/Log.h>

#include "ARTPWriter1.h"

#include <fcntl.h>

#include <media/stagefright/foundation/ABuffer.h>
#include <media/stagefright/foundation/ADebug.h>
#include <media/stagefright/foundation/AMessage.h>
#include <media/stagefright/foundation/hexdump.h>
#include <media/stagefright/MediaBuffer.h>
#include <media/stagefright/MediaDefs.h>
#include <media/stagefright/MediaSource.h>
#include <media/stagefright/MetaData.h>
#include <utils/ByteOrder.h>

#define PT      97
#define PT_STR  "97"

namespace android {

// static const size_t kMaxPacketSize = 65507;  // maximum payload in UDP over IP
static const size_t kMaxPacketSize = 1500;

static int UniformRand(int limit) {
    return ((double)rand() * limit) / RAND_MAX;
}

ARTPWriter1::ARTPWriter1(int fd)
    : mFlags(0),
      mFd(dup(fd)),
      mLooper(new ALooper),
      mReflector(new AHandlerReflector<ARTPWriter1>(this)) {
    CHECK_GE(fd, 0);

    mLooper->setName("rtp writer");
    mLooper->registerHandler(mReflector);
    mLooper->start();


}

ARTPWriter1::~ARTPWriter1() {
	ALOGE("~ARTPWriter1222==============");
    close(mFd);
    mFd = -1;
    mHardView = NULL;
    ALOGE("~ARTPWriter13333==============");
}

status_t ARTPWriter1::addSource(const sp<MediaSource> &source) {
    mSource = source;
    return OK;
}

bool ARTPWriter1::reachedEOS() {
    Mutex::Autolock autoLock(mLock);
    return (mFlags & kFlagEOS) != 0;
}

status_t ARTPWriter1::start(MetaData *params) {
    Mutex::Autolock autoLock(mLock);
    if (mFlags & kFlagStarted) {
        return INVALID_OPERATION;
    }

    mFlags &= ~kFlagEOS;


    const char *mime;
    CHECK(mSource->getFormat()->findCString(kKeyMIMEType, &mime));
    ALOGE(" mime info=====%s",mime);
    mMode = INVALID;
    if (!strcasecmp(mime, MEDIA_MIMETYPE_VIDEO_AVC)) {
        mMode = H264;
    } else if (!strcasecmp(mime, MEDIA_MIMETYPE_VIDEO_H263)) {
        mMode = H263;
    } else if (!strcasecmp(mime, MEDIA_MIMETYPE_AUDIO_AMR_NB)) {
        mMode = AMR_NB;
    } else if (!strcasecmp(mime, MEDIA_MIMETYPE_AUDIO_AMR_WB)) {
        mMode = AMR_WB;
    } else if (!strcasecmp(mime, MEDIA_MIMETYPE_VIDEO_RAW)) {
        mMode = VIDEO_RAW;
    } else {
        TRESPASS();
    }

    (new AMessage(kWhatStart, mReflector->id()))->post();

    while (!(mFlags & kFlagStarted)) {
        mCondition.wait(mLock);
    }

    return OK;
}

status_t ARTPWriter1::stop() {
	ALOGE("ARTPWriter1::stop() (mFlags & kFlagStarted)=%d",(mFlags & kFlagStarted));
    Mutex::Autolock autoLock(mLock);
    if (!(mFlags & kFlagStarted)) {
        return OK;
    }
    ALOGE("ARTPWriter1::stop() 2(mFlags & kFlagStarted)=%d",(mFlags & kFlagStarted));
    (new AMessage(kWhatStop, mReflector->id()))->post();
    ALOGE("ARTPWriter1::stop() 3(mFlags & kFlagStarted)=%d",(mFlags & kFlagStarted));
    while (mFlags & kFlagStarted) {
        mCondition.wait(mLock);
    }
    ALOGE("ARTPWriter1::stop() 4(mFlags & kFlagStarted)=%d",(mFlags & kFlagStarted));
    return OK;
}

status_t ARTPWriter1::pause() {
    return OK;
}

void ARTPWriter1::StripStartcode(MediaBuffer *buffer) {
    if (buffer->range_length() < 4) {
        return;
    }
    const uint8_t *ptr = (const uint8_t *)buffer->data() + buffer->range_offset();
    write(mFd, ptr , buffer->range_length());

    /*
    const uint8_t *ptr =
        (const uint8_t *)buffer->data() + buffer->range_offset();

    if (!memcmp(ptr, "\x00\x00\x00\x01", 4)) {
        buffer->set_range(
                buffer->range_offset() + 4, buffer->range_length() - 4);
    }
    */
}



void ARTPWriter1::onMessageReceived(const sp<AMessage> &msg) {
	//ALOGE("onMessageReceived ======msg.what=%d;kWhatStart=%d;kWhatStop=%d;kWhatRead=%d;kWhatSendSR=%d",msg->what(),kWhatStart,kWhatStop,kWhatRead,kWhatSendSR);
    switch (msg->what()) {
        case kWhatStart:
        {
            {
                Mutex::Autolock autoLock(mLock);

                CHECK_EQ(mSource->start(), (status_t)OK);


                MediaBuffer *buffer;
                CHECK_EQ(mSource->read(&buffer), (status_t)OK);
                ALOGE("mSource->read(&buffer)==============%d",buffer->range_length());
                StripStartcode(buffer);
                buffer->release();
                buffer = NULL;

                mFlags |= kFlagStarted;
                mCondition.signal();
            }

            (new AMessage(kWhatRead, mReflector->id()))->post();
            //(new AMessage(kWhatSendSR, mReflector->id()))->post();
            ALOGE(" (new AMessage(kWhatRead, mReflector->id()))->post()=====%d",msg->what());

            sp < MetaData > meta = mSource->getFormat();
        	int32_t width, height;
        	CHECK(meta->findInt32(kKeyWidth, &width));
        	CHECK(meta->findInt32(kKeyHeight, &height));

//            mHardView = new HardView(width,height,meta);
//            mHardView->initWindow();
            break;
        }

        case kWhatStop:
        {
            CHECK_EQ(mSource->stop(), (status_t)OK);
            ALOGE("mSource->stop(), (status_t)OK");
            {
                Mutex::Autolock autoLock(mLock);
                mFlags &= ~kFlagStarted;
                mCondition.signal();
            }

            mHardView = NULL;
            break;
        }

        case kWhatRead:
        {
            {
                Mutex::Autolock autoLock(mLock);
                if (!(mFlags & kFlagStarted)) {
                    break;
                }
            }
            onRead(msg);
//            if(!mHardView->android()){
//            	mHardView->checkExit();
//            }
            break;
        }

        case kWhatSendSR:
        {
            {
                Mutex::Autolock autoLock(mLock);
                if (!(mFlags & kFlagStarted)) {
                    break;
                }
            }

 //           onSendSR(msg);
            break;
        }

        default:
            TRESPASS();
            break;
    }
}

void ARTPWriter1::onRead(const sp<AMessage> &msg) {
    MediaBuffer *mediaBuf;
    status_t err = mSource->read(&mediaBuf);
    if (err != OK) {
        ALOGI("reached EOS.");

        Mutex::Autolock autoLock(mLock);
        mFlags |= kFlagEOS;
        return;
    }

    if (mediaBuf->range_length() > 0) {
    	ALOGE("mediaBuf  offset=%d ;length=%d", mediaBuf->range_offset(),mediaBuf->range_length());
    	//mHardView->setImage(mediaBuf);
        StripStartcode(mediaBuf);
    }

    mediaBuf->release();
    mediaBuf = NULL;

    msg->post();
}
}  // namespace android

