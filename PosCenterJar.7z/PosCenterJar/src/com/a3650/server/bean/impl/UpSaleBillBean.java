package com.a3650.server.bean.impl;

import com.a3650.server.bean.UpCommandBean;

public class UpSaleBillBean extends UpCommandBean{

	public void parseBody(byte[] body) {
		// TODO Auto-generated method stub
		
	}
}
